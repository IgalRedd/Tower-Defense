//Author: Igal Brener
//FileName: main.cs
//Project Name: Final project
//Creation Date: 8 / 06 / 2021
//Modified Date: 16 / 06 / 2021
//Description: Driver class

using System;
using System.Collections.Generic;

// Import libraries for IO files
using System.IO;

class MainClass : AbstractGame
{
  //Game States - Add/Remove/Modify as needed
  //These are the most common game states, but modify as needed
  //You will ALSO need to modify the two switch statements in Update and Draw
  private const int MENU = 0;
  private const int LOGIN = 1;
  private const int INSTRUCTIONS = 2;
  private const int GAMEPLAY = 3;
  private const int PAUSE = 4;
  private const int ENDGAME = 5;
  private const int STATISTICS = 6;

  //Choose between UI_RIGHT, UI_LEFT, UI_TOP, UI_BOTTOM, UI_NONEs
  private static int uiLocation = Helper.UI_NONE;

  ////////////////////////////////////////////
  //Set the game and user interface dimensions
  ////////////////////////////////////////////

  //Min: 5 top/bottom, 10 left/right, Max: 30
  private static int uiSize = 4;

  //On VS: Max: 120 - uiSize, UI_NONE gives full width up to 120
  //On Repl: Max: 80 - uiSize, UI_NONE can give full width up to 80
  private static int gameWidth = 80;

  //On VS: Max: 50 - uiSize, UI_NONE gives full height up to 50
  //On Repl: Max: 24 - uiSize, UI_NONE can give full height up to 24
  private static int gameHeight = 24;

  //Store and set the initial game state, typically MENU to start
  int gameState = LOGIN;

  ////////////////////////////////////////////
  //Define your Global variables here (They do NOT need to be static)
  ////////////////////////////////////////////

  // Creates list of user objects to store the users
  List<User> users = new List<User>();

  // Creates game text object to store the current username
  GameTextObject currentUsernameText;

  // Stores a string of the current username
  string currentUsername;

  // Creates variable to store the user
  User currentUser;

  // Creates text object to inform player about info in the login
  GameTextObject loginInfoText;
  GameTextObject loginInfoText1;

  // Creates image of the pointer and store it's object
  Image pointerImg;
  GameObject pointerObject;

  // Creates integer to store where the pointer is currently pointing
  int pointer = 0;

  // Stores which screen it is currently on
  int chosenScreen = 0;

  // Creates image and object for the choosign a username
  Image chooseUserImg;
  GameObject chooseObject;

  // Creates image and object for creating a new user
  Image createUserImg;
  GameObject createObject;

  // Creates constant to store the file name
  const string fileName = "users.txt";

  // Creates image and object for instructions
  Image InstructionsImg;
  GameObject instructionObject;

  // Creates image and object for play button
  Image PlayImg;
  GameObject playObject;

  // Creates image and object for statistics button
  Image StatsImg;
  GameObject statsObject;

  // Creates image and object for log out butotn
  Image logOutImg;
  GameObject logOutObject;

  // Creates image and object for exit button
  Image exitImg;
  GameObject exitObject;

  // Creates text objects for goals of the game
  GameTextObject goalText;
  GameTextObject goalText1;

  // Creates text objects for rule of the game
  GameTextObject gameRules;
  GameTextObject gameRules1;

  // Creates text objects for enemy describitinos
  GameTextObject enemyDesc;
  GameTextObject enemyDesc1;
  GameTextObject enemyDesc2;
  GameTextObject enemyDesc3;
  GameTextObject enemyDesc4;

  // Creates text objects for tower describitinos
  GameTextObject towerDesc;
  GameTextObject towerDesc1;
  GameTextObject towerDesc2;
  GameTextObject towerDesc3;
  GameTextObject towerDesc4;

  // Creates text objects for upgrade describitinos
  GameTextObject upgradeDesc;
  GameTextObject upgradeDesc1;
  GameTextObject upgradeDesc2;
  GameTextObject upgradeDesc3;
  GameTextObject upgradeDesc4;

  // Creates text objects for instruction describitinos
  GameTextObject howTo;
  GameTextObject howTo1;

  // Creates image and object for user stats button
  Image userStatsImg;
  GameObject userStatsObject;

  // Creates image and object for the leaderboard button
  Image LeaderboardImg;
  GameObject leaderboardObject;

  // Create text objects to store personal information
  GameTextObject usernameText;
  GameTextObject maxGoldText;
  GameTextObject maxLevelText;
  GameTextObject lifetimeText;
  GameTextObject totalGamesText;
  GameTextObject totalKills;
  GameTextObject averageGold;

  // Creates constants to store which sorting
  const int MAXGOLD = 0;
  const int MAXLEVEL = 1;
  const int TOTALKILLS = 2; 
  const int TOTALPLAYS = 3;
  const int LIFETIMEGOLD = 4;
  const int AVERAGEGOLD = 5;

  // Creates integer to store the current storing 
  int currentSorting;

  // Creates image and object for the max gold button
  Image maxGoldImg;
  GameObject maxGoldObject;

  // Creates image and object for max level button
  Image maxLevelImg;
  GameObject maxLevelObject;

  // Creates image and object for total kills button
  Image totalKillsImg;
  GameObject totalKillsObject;

  // Creates image and object for total plays button
  Image totalPlaysImg;
  GameObject totalPlaysObject;

  // Creates image and object for lifetime gold butotn
  Image lifetimeGoldImg;
  GameObject lifetimeGoldObject;

  // Creates image and object for average gold button
  Image averageGoldImg;
  GameObject averageGoldObject;

  // Create array to store the leaderboard text info
  GameTextObject[] leaderboardText = new GameTextObject[10];

  // Creates image and object for pause button
  Image pauseImg;
  GameObject pauseObject;

  // Creates text objects for the pause texdt
  GameTextObject pauseText1;
  GameTextObject pauseText2;

  // Text object to store the level the current player is on, and the integer to store level
  GameTextObject levelText;
  int level = 1;

  // Text object to store the amount of gold the player has, and the integer to store gold
  GameTextObject goldText;
  int gold = 20;

  // Creates variables to store the text to display the home HP and HP bar
  GameTextObject homeHPText;
  GameBarObject homeHPBar;
  int HP = 30;
  const int maxHP = 30;

  // Creates variables to store the text to display the head start text, and head start bar
  GameTextObject headStartText;
  GameBarObject headStartBar;
  // Creates variables to store the amount of time the player currently has and how much it is out of
  float timeLeft = 30000f;
  int maxTime = 30000;  

  // Creates variables to store the text to display the adds text and adds bar
  GameTextObject addsText;
  GameBarObject addsBar;
  // Creates variables to store how many adds are currently left and out of how much it is
  int addsLeft = 1;
  int maxAdds = 1;

  // Creates text variables to store text to build all towers
  GameTextObject archerBuildText;
  GameTextObject barrierBuildText;
  GameTextObject mudBuildText;
  GameTextObject cannonBuildText;

  // Game text to store build text
  GameTextObject buildText;

  // Creates text variables to store the text to upgrade the towers
  GameTextObject archerUpgradeText;
  GameTextObject barrierUpgradeText;
  GameTextObject mudUpgradeText;
  GameTextObject cannonUpgradeText;

  // Game text to store the upgrade text
  GameTextObject upgradeText;

  // Creates the text to display the destroy
  GameTextObject destroyText;

  // Displays the text to inform the user of what the following text is
  GameTextObject activeText;

  // Displays the actual current towers
  GameTextObject currentActiveText;

  // Creates the queue to store the action queue
  ActionQueue queue = new ActionQueue();

  // Variables to store the image of the regular tile and selected tile
  Image tileImg;
  Image selectedTileImg;

  // 2D array to store the tile objects
  Tile[,] tiles = new Tile[10,4];

  // Creates a variable to store where the player's "cursor" is (which tile they are currently on)
  int cursor = 0;

  // Variables for tower images
  Image archerTowerImg;
  Image barrierImg;
  Image mudTrapImg;

  // Variable for the image of the arrow from the archer tower
  Image arrowImg;

  // Creates list to store bullets in the game
  List<GameObject> bullets = new List<GameObject>();

  // Stores the tower objects
  List<Tower> towerObjects = new List<Tower>();

  // Creates constant to store the amount to multiply by for the refund cost
  const float REFUNDCOST = 0.5f;

  // Variables for enemies images
  Image enemyGMImg;
  Image enemyFMImg;
  Image bossImg;

  // Creates a variable to keep track of how long until a zombie is spawned
  float waveSpawner;

  // Creates the stack to hold the enemies
  EnemyStack stack = new EnemyStack();

  // Create bool to indicate if the spawning phase is done or not
  bool spawnPhase = false;

  // Creates a list to store all the enemies that are to be drawn
  List<Enemy> enemies = new List<Enemy>();

  // Creates integer to store which row the enemy was spawned on previously, sets it to be invalid for now so it can be used the first time
  int prevRow = -1;

  // Creates integer to store where the boss was last placed
  int prevBossRow = 0;

  // Tracks statistics for each endgame phase
  int totalGoldChange = 0;
  int bossesKilled = 0;
  int addsKilled = 0;
  int towersPlaced = 0;

  // Creates text objects to display the statistics tracked
  GameTextObject totalGoldChangeText;
  GameTextObject bossesKilledText;
  GameTextObject addsKilledText;
  GameTextObject towersPlacedText;

  // Creates text object to inform user of statistics
  GameTextObject statisticsText;

  // Text object to tell the user if they won or lost
  GameTextObject endGameText;

  static void Main(string[] args)
  {
    /***************************************************************
                DO NOT TOUCH THIS SECTION
    ***************************************************************/
    GameContainer gameContainer = new GameContainer(new MainClass(), uiLocation, uiSize, gameWidth, gameHeight);
    gameContainer.Start();
  }

  public override void LoadContent(GameContainer gc)
  {
    //Load all of your "Images", GameObjects and UIObjects here.
    //This is also the place to setup any other aspects of your program before the game loop starts

    // Initially reads the file
    ReadFile();

    // Loads in the current username text
    currentUsernameText = new GameTextObject(gc, 10, 5, Helper.WHITE, true, "Username:");

    // Loads the text object to provide info for the login screen
    loginInfoText = new GameTextObject(gc, 10, 6, Helper.WHITE, true, "");
    loginInfoText1 = new GameTextObject(gc, 10, 7, Helper.WHITE, true, "");

    // Loads in pointer
    pointerImg = Helper.LoadImage("Images/MenuOptions/Pointer.txt");
    pointerObject = new GameObject(gc, pointerImg, 30, 6, true);

    // Loads in choice button
    chooseUserImg = Helper.LoadImage("Images/MenuOptions/ChooseUser.txt");
    chooseObject = new GameObject(gc, chooseUserImg, 35, 5, true);

    // Loads in creation user button
    createUserImg = Helper.LoadImage("Images/MenuOptions/CreateUser.txt");
    createObject = new GameObject(gc, createUserImg, 35, 10, true);

    // Loads in playing butotn
    PlayImg = Helper.LoadImage("Images/MenuOptions/Play.txt");
    playObject = new GameObject(gc, PlayImg, 35, 1, true);

    // Loads in instrction button
    InstructionsImg = Helper.LoadImage("Images/MenuOptions/Instructions.txt");
    instructionObject = new GameObject(gc, InstructionsImg, 35, 6, true);

    // Loads in stats button
    StatsImg = Helper.LoadImage("Images/MenuOptions/Stats.txt");
    statsObject = new GameObject(gc, StatsImg, 35, 11, true);

    // Loads in logout button
    logOutImg = Helper.LoadImage("Images/MenuOptions/Logout.txt");
    logOutObject = new GameObject(gc, logOutImg, 35, 16, true);

    // Loads in exit button
    exitImg = Helper.LoadImage("Images/MenuOptions/Exit.txt");
    exitObject = new GameObject(gc, exitImg, 35, 21, true);

    // Loads in goals text
    goalText = new GameTextObject(gc, 0, 0, Helper.RED, true, "Goal:");
    goalText1 = new GameTextObject(gc, 0, 1, Helper.WHITE, true, "The goal of the game is to surive as many levels with highest gold");

    // Loads in games rule text
    gameRules = new GameTextObject(gc, 0, 2, Helper.RED, true, "Rules:");
    gameRules1 = new GameTextObject(gc, 0, 3, Helper.WHITE, true, "Arrow keys to move, use the ingame overlay to build");

    // Loads in enemy desscrition text
    enemyDesc = new GameTextObject(gc, 0, 4, Helper.RED, true, "Enemies:");
    enemyDesc1 = new GameTextObject(gc, 0, 5, Helper.WHITE, true, "1.3 HP that deals 2 damage, being the second slowest enemy.");
    enemyDesc2 = new GameTextObject(gc, 0, 6, Helper.WHITE, true, "2.8 HP that deals 3 damage from a range of 3 tiles, being second fastest enemy");
    enemyDesc3 = new GameTextObject(gc, 0, 7, Helper.WHITE, true, "3.4 HP that deals 1 damage, being the fastest enemy that can fly above mud traps");
    enemyDesc4 = new GameTextObject(gc, 0, 8, Helper.WHITE, true, "4.50 HP that deals 4 damage, being the slowest enemy. This is the boss");

    // Loads in tower describitinos text
    towerDesc = new GameTextObject(gc, 0, 9, Helper.RED, true, "Towers:");
    towerDesc1 = new GameTextObject(gc, 0, 10, Helper.WHITE, true, "1.Archer tower shoots arrow for 6 tiles, each dealing 1 damage");
    towerDesc2 = new GameTextObject(gc, 0, 11, Helper.WHITE, true, "2.Barrier is a wall that has 30 HP");
    towerDesc3 = new GameTextObject(gc, 0, 12, Helper.WHITE, true, "3.Mud traps slow down enemies, they have 5 uses and slow rate of 0.5");
    towerDesc4 = new GameTextObject(gc, 0, 13, Helper.WHITE, true, "4.There is no cannon ");

    // Loads in upgradeDesc text
    upgradeDesc = new GameTextObject(gc, 0, 14, Helper.RED, true, "Upgrades:");
    upgradeDesc1 = new GameTextObject(gc, 0, 15, Helper.WHITE, true, "1.Archer tower upgrades: tile range to 8, damage to 2.8");
    upgradeDesc2 = new GameTextObject(gc, 0, 16, Helper.WHITE, true, "2.Barrier upgrades HP to 30");
    upgradeDesc3 = new GameTextObject(gc, 0, 17, Helper.WHITE, true, "3.Mud trap upgreas to 8 uses and slow rate of 0.3");
    upgradeDesc4 = new GameTextObject(gc, 0, 18, Helper.WHITE, true, "4.The cannon never existed");

    // Loads in user stats button
    userStatsImg = Helper.LoadImage("Images/MenuOptions/UserStats.txt");
    userStatsObject = new GameObject(gc, userStatsImg, 35, 5, true);

    // Loads in leader button
    LeaderboardImg = Helper.LoadImage("Images/MenuOptions/Leaderboard.txt");
    leaderboardObject = new GameObject(gc, LeaderboardImg, 35, 15, true);

    // Loads in perosna info text
    usernameText = new GameTextObject(gc, 20, 5, Helper.WHITE, true, "");
    maxGoldText = new GameTextObject(gc, 20, 6, Helper.WHITE, true, "");
    maxLevelText = new GameTextObject(gc, 20, 7, Helper.WHITE, true, "");
    lifetimeText = new GameTextObject(gc, 20, 8, Helper.WHITE, true, "");
    totalGamesText = new GameTextObject(gc, 20, 9, Helper.WHITE, true, "");
    totalKills = new GameTextObject(gc, 20, 10, Helper.WHITE, true, "");
    averageGold = new GameTextObject(gc, 20, 11, Helper.WHITE, true, "");

    // Loads in buttons for sorting types
    maxGoldImg = Helper.LoadImage("Images/MenuOptions/SortingOptions/MaxGold.txt");
    maxGoldObject = new GameObject(gc, maxGoldImg, 35, 0, true);
    maxLevelImg = Helper.LoadImage("Images/MenuOptions/SortingOptions/MaxLevel.txt");
    maxLevelObject = new GameObject(gc, maxLevelImg, 35, 4, true);
    totalKillsImg = Helper.LoadImage("Images/MenuOptions/SortingOptions/TotalKills.txt");
    totalKillsObject = new GameObject(gc, totalKillsImg, 35, 8, true);
    totalPlaysImg = Helper.LoadImage("Images/MenuOptions/SortingOptions/TotalPlays.txt");
    totalPlaysObject = new GameObject(gc, totalPlaysImg, 35, 12, true);
    lifetimeGoldImg = Helper.LoadImage("Images/MenuOptions/SortingOptions/LifetimeGold.txt");
    lifetimeGoldObject = new GameObject(gc, lifetimeGoldImg, 35, 16, true);
    averageGoldImg = Helper.LoadImage("Images/MenuOptions/SortingOptions/AverageGold.txt");
    averageGoldObject = new GameObject(gc, averageGoldImg, 35, 20, true);
    
    // Loops through all leader text
    for (int i = 0; i < leaderboardText.Length; i++)
    {
      // Loads in text of leaderboard leaders
      leaderboardText[i] = new GameTextObject(gc, 30, 3 + i + (i / 2), Helper.WHITE, true, "");
    }

    // Loads in pause button
    pauseImg = Helper.LoadImage("Images/MenuOptions/Pause.txt");
    pauseObject = new GameObject(gc, pauseImg, 30, 5, true);

    // Loads in pause text
    pauseText1 = new GameTextObject(gc, 25, 10, Helper.WHITE, true, "Press ENTER to go back into the game");
    pauseText2 = new GameTextObject(gc, 25, 11, Helper.WHITE, true, "Press ESCAPE to go back to the main menu");

    // Loads up the level text
    levelText = new GameTextObject(gc, 0, 20, Helper.WHITE, true, "Level:" + level);

    // Loads up the gold text
    goldText = new GameTextObject(gc, 11, 20, Helper.YELLOW, true, "Gold:" + gold);

    // Loads up all the texts and bar object for the HP of the base
    homeHPText = new GameTextObject(gc, 1, 21, Helper.WHITE, true, "Home Base:");
    homeHPBar = new GameBarObject(gc, 11, 21, Helper.RED, true, maxHP, HP, 9); 

    // Loads up all the text and bar object for the timer
    headStartText = new GameTextObject(gc, 0, 22, Helper.WHITE, true, "Head Start:");
    headStartBar = new GameBarObject(gc, 11, 22, Helper.RED, true, (int)timeLeft, maxTime, 9);

    // Loads up all the adds text and bar object
    addsText = new GameTextObject(gc, 1, 23, Helper.WHITE, true, "Adds Left:");
    addsBar = new GameBarObject(gc, 11, 23, Helper.RED, true, addsLeft, maxAdds, 9);

    // Loads up the build text and text for each buildings
    buildText = new GameTextObject(gc, 22, 21, Helper.WHITE, true, "Build");
    archerBuildText = new GameTextObject(gc, 28, 20, Helper.WHITE, true, "1.Archer Tower");
    barrierBuildText = new GameTextObject(gc, 28, 21, Helper.WHITE, true, "2.Barrier");
    mudBuildText = new GameTextObject(gc, 28, 22, Helper.WHITE, true, "3.Mud Trap");
    cannonBuildText = new GameTextObject(gc, 28, 23, Helper.WHITE, true, "4.Cannon");

    // Loads up all the upgrade text and text for each building
    upgradeText = new GameTextObject(gc, 43, 21, Helper.WHITE, true, "Upgrade");
    archerUpgradeText = new GameTextObject(gc, 51, 20, Helper.WHITE, true, "Q.Archer Tower");
    barrierUpgradeText = new GameTextObject(gc, 51, 21, Helper.WHITE, true, "W.Barrier");
    mudUpgradeText = new GameTextObject(gc, 51, 22, Helper.WHITE, true, "E.Mud Trap");
    cannonUpgradeText = new GameTextObject(gc, 51, 23, Helper.WHITE, true, "R.Cannon");   

    // Loads the destroy text
    destroyText = new GameTextObject(gc, 70, 20, Helper.WHITE, true, "X.Destroy"); 
    // Loads the active text to inform the user of the current active action
    activeText = new GameTextObject(gc, 66, 22, Helper.WHITE, true, "Active Action");
    currentActiveText = new GameTextObject(gc, 66, 23, Helper.WHITE, true, "-");

    // Loads in the 2 tile images, both selected and unselected
    tileImg = Helper.LoadImage("Images/Tile.txt");
    selectedTileImg = Helper.LoadImage("Images/SelectedTile.txt");

    // Loops through coloums of tiles
    for (int i = 0; i < tiles.GetLength(0); i++)
    {
      // Loops through rows of tiles
      for (int b = 0; b < tiles.GetLength(1); b++)
      {
        // Instanciates a new tile object, passing in all the parameters
        tiles[i,b] = new Tile(tileImg, selectedTileImg, new GameObject(gc, tileImg, Tile.startingTileDistance + (Tile.tileHeight * i), Tile.tileWidth * b, true) );

        // Checks if its the first tile 
        if (i == 0 && b == 0)
        {
          // Highlites it to show how this is the selected tile initially
          tiles[i,b].SelectTile(gc);
        }
      }
    }

    // Loads up tower images
    archerTowerImg = Helper.LoadImage("Images/ArcherTower.txt");
    barrierImg = Helper.LoadImage("Images/Barrier.txt");
    mudTrapImg = Helper.LoadImage("Images/MudTrap.txt");

    // Loads up the arrow for the archer tower
    arrowImg = Helper.LoadImage("Images/Arrow.txt");

    // Load enemy images
    enemyGMImg = Helper.LoadImage("Images/EnemyGM.txt");
    enemyFMImg = Helper.LoadImage("Images/EnemyFM.txt");
    bossImg = Helper.LoadImage("Images/Boss.txt");

    // Loads in the text boxes for the statistics, no need to fill them with text as it will change anyways
    totalGoldChangeText = new GameTextObject(gc, 29, 13, Helper.WHITE, true, "");
    bossesKilledText = new GameTextObject(gc, 29, 14, Helper.WHITE, true, "");
    addsKilledText = new GameTextObject(gc, 29, 15, Helper.WHITE, true, "");
    towersPlacedText = new GameTextObject(gc, 29, 16, Helper.WHITE, true, "");

    // Load text to inform the user that it is statistics
    statisticsText = new GameTextObject(gc, 29, 12, Helper.WHITE, true, "Statistics:");

    // Loads the end game text object
    endGameText = new GameTextObject(gc, 20, 10, Helper.WHITE, true, "");

  }

  public override void Update(GameContainer gc, float deltaTime)
  { 
    switch (gameState)
    {
      case MENU:
        //Get and implement menu interactions

        UpdateMenu(gc);
        break;
      case LOGIN:
        //Get and apply changes to game LOGIN

        // Calls upon subprogram to deal with
        UpdateLogin(gc);
        break;
      case INSTRUCTIONS:
        //Get user input to return to MENU

        if (Input.IsKeyDown(ConsoleKey.Escape))
        {
          gameState = MENU;
        }
        break;
      case GAMEPLAY:
        //Implement standared game logic (input, update game objects, apply physics, collision detection)

        // Calls update game to do all the work for updating the game
        UpdateGame(deltaTime, gc);
        break;
      case PAUSE:
        //Get user input to resume the game

        UpdatePause();
        break;
      case ENDGAME:
        //Wait for final input based on end of game options (end, restart, etc.)

        // Calls upon subprogram to deal with end game
        UpdateEndgame(gc);
        break;
      case STATISTICS:
        UpdateStats(gc);
      break;
    }
  }

  public override void Draw(GameContainer gc)
  {
    //NOTE: The only logic in this section should be draw commands and loops.
    //There may be some minor selection, but choosing what to draw 
    //should be handled in the Update and the visibility property 
    //of GameObject's

    switch (gameState)
    {
      case MENU:
        //Draw the possible menu options

        DrawMenu(gc);
        break;
      case LOGIN:
        //Draw the LOGIN with prompts

        // Calls upon the subprogram to deal with
        DrawLogin(gc);
        break;
      case INSTRUCTIONS:
        //Draw the game instructions including prompt to return to MENU

        // Calls the subprogram
        DrawInstruction(gc);
        break;
      case GAMEPLAY:
        //Draw all game objects on each layers (background, middleground, foreground and user interface)

        // Calls upon draw game to handle all the drawing
        DrawGame(gc);
        break;
      case PAUSE:
        //Draw the pause screen, this may include the full game drawing behind

        DrawPause(gc);
        break;
      case ENDGAME:
        //Draw the final feedback and prompt for available options (exit,restart, etc.)
        
        // Calls upon subprogram to handle drawing
        DrawEndgame(gc);
        break;
      case STATISTICS:
        DrawStats(gc);
      break;
    }
  }

  // Pre: Takes in the game container to draw
  // Post: None
  // Desc: Draws all the objects when the player is playing the game
  public void DrawGame(GameContainer gc)
  {
    // Draws level text
    gc.DrawToBackground(levelText);

    // Draws gold text
    gc.DrawToBackground(goldText);

    // Draws home HP information
    gc.DrawToBackground(homeHPText);
    gc.DrawToBackground(homeHPBar); 

    // Draws head start information
    gc.DrawToBackground(headStartText);
    gc.DrawToBackground(headStartBar);

    // Draws the adds information
    gc.DrawToBackground(addsText);
    gc.DrawToBackground(addsBar);

    // Draws all the build text
    gc.DrawToBackground(buildText);
    gc.DrawToBackground(archerBuildText);
    gc.DrawToBackground(barrierBuildText);
    gc.DrawToBackground(mudBuildText);
    gc.DrawToBackground(cannonBuildText);

    // Draws all the upgrade text
    gc.DrawToBackground(upgradeText);
    gc.DrawToBackground(archerUpgradeText);
    gc.DrawToBackground(barrierUpgradeText);
    gc.DrawToBackground(mudUpgradeText);
    gc.DrawToBackground(cannonUpgradeText);

    // Draws the destroyText
    gc.DrawToBackground(destroyText);

    // Draws the active text and information
    gc.DrawToBackground(activeText);
    gc.DrawToBackground(currentActiveText);

    // Loops through all coloums
    for (int i = 0; i < tiles.GetLength(0); i++)
    {
      // Loops through all rows
      for (int b = 0; b < tiles.GetLength(1); b++)
      {
        // Draws the actual tile
        gc.DrawToBackground(tiles[i,b].GetObject());
      }
    }

    // Loops through all towers
    for (int i = 0; i < towerObjects.Count; i++)
    {
      // Draws the current tower
      gc.DrawToBackground(towerObjects[i].GetObject());
    }

    // Loops through all the enemies
    for (int i = 0; i < enemies.Count; i++)
    {
      // Draws the current enemy
      gc.DrawToMidground(enemies[i].GetObject());
    }

    // Loops through every bullets
    for (int i = 0; i < bullets.Count; i++)
    {
      // Draws the current bullet
      gc.DrawToMidground(bullets[i]);
    }

  }

  // Pre: Takes in the game container to draw
  // Post: None
  // Desc: Draws all the objects when the player is paused
  public void DrawPause(GameContainer gc)
  {
    // Loads in pause button
    gc.DrawToBackground(pauseObject);

    // Loads in text stuff
    gc.DrawToBackground(pauseText1);
    gc.DrawToBackground(pauseText2); 
    
  }

  // Pre: Takes in the game container to draw
  // Post: None
  // Desc: Draws all the text for the current state
  public void DrawInstruction(GameContainer gc)
  {
    // Loads in all the text to describie instructions
    gc.DrawToBackground(goalText);
    gc.DrawToBackground(goalText1);

    gc.DrawToBackground(gameRules);
    gc.DrawToBackground(gameRules1);

    gc.DrawToBackground(enemyDesc);
    gc.DrawToBackground(enemyDesc1);
    gc.DrawToBackground(enemyDesc2);
    gc.DrawToBackground(enemyDesc3);
    gc.DrawToBackground(enemyDesc4);

    gc.DrawToBackground(towerDesc);
    gc.DrawToBackground(towerDesc1);
    gc.DrawToBackground(towerDesc2);
    gc.DrawToBackground(towerDesc3);
    gc.DrawToBackground(towerDesc4);

    gc.DrawToBackground(upgradeDesc);
    gc.DrawToBackground(upgradeDesc1);
    gc.DrawToBackground(upgradeDesc2);
    gc.DrawToBackground(upgradeDesc3);
    gc.DrawToBackground(upgradeDesc4);
  }

  // Pre: Takes in the game container to draw
  // Post: None
  // Desc: Draws all the text for the current state
  public void DrawStats(GameContainer gc)
  {
    // Chooses what to laod based on screen
    if (chosenScreen == 0)
    {
      // Loads in the stats buttons
      gc.DrawToBackground(userStatsObject);
      gc.DrawToBackground(leaderboardObject);

      gc.DrawToBackground(pointerObject);
    }
    else if (chosenScreen == 1)
    {
      // Loads in personal stats
      gc.DrawToBackground(maxGoldObject);
      gc.DrawToBackground(maxLevelObject);
      gc.DrawToBackground(totalKillsObject);
      gc.DrawToBackground(totalPlaysObject);
      gc.DrawToBackground(lifetimeGoldObject);
      gc.DrawToBackground(averageGoldObject);

      gc.DrawToBackground(pointerObject);
    }
    else if (chosenScreen == 2)
    {
      // Loads in sorting butotns
      gc.DrawToBackground(usernameText);
      gc.DrawToBackground(maxGoldText);
      gc.DrawToBackground(maxLevelText);
      gc.DrawToBackground(lifetimeText);
      gc.DrawToBackground(totalGamesText);
      gc.DrawToBackground(totalKills);
      gc.DrawToBackground(averageGold);
    }
    else
    {
      // Loosp through leaders
      for (int i = 0; i < leaderboardText.Length; i++)
      {
        // Loads in the current leader
        gc.DrawToBackground(leaderboardText[i]);
      }
    }
    
  }

  // Pre: Takes in the game container to draw
  // Post: None
  // Desc: Draws all the text for the end phase state
  public void DrawEndgame(GameContainer gc)
  {
    // Updates the texts to reflect the actual statistics
    totalGoldChangeText.UpdateText("Your gold changed by: " + totalGoldChange);
    bossesKilledText.UpdateText("You killed: " + bossesKilled + " bosses");
    addsKilledText.UpdateText("You killed: " + addsKilled + " adds");
    towersPlacedText.UpdateText("You placed: " + towersPlaced + " towers");

    // Draws the text objects
    gc.DrawToBackground(totalGoldChangeText);
    gc.DrawToBackground(bossesKilledText);
    gc.DrawToBackground(addsKilledText);
    gc.DrawToBackground(towersPlacedText);

    // Draws the statistics text
    gc.DrawToBackground(statisticsText);

    // Draws the end game text
    gc.DrawToBackground(endGameText);
  }

  // Pre: Takes in the game container to draw
  // Post: None
  // Desc: Draws all the objects when the player is logiing in
  public void DrawLogin(GameContainer gc)
  {
    if (chosenScreen > 0)
    {
      gc.DrawToBackground(currentUsernameText);
      gc.DrawToBackground(loginInfoText);
      gc.DrawToBackground(loginInfoText1);
    }
    else
    {
      gc.DrawToBackground(chooseObject);
      gc.DrawToBackground(createObject);

      gc.DrawToBackground(pointerObject);
    }
  }

  // Pre: Takes in the game container to draw
  // Post: None
  // Desc: Draws all the objects when the player is in the menu
  public void DrawMenu(GameContainer gc)
  {
    gc.DrawToBackground(playObject);
    gc.DrawToBackground(statsObject);
    gc.DrawToBackground(instructionObject);
    gc.DrawToBackground(logOutObject);
    gc.DrawToBackground(exitObject);

    gc.DrawToBackground(pointerObject);
  }

  // Pre: None
  // Post: None
  // Desc: Updateds all stuff for pause menu
  public void UpdatePause()
  {
    if (Input.IsKeyDown(ConsoleKey.Enter))
    {
      gameState = GAMEPLAY;
    }
    else if (Input.IsKeyDown(ConsoleKey.Escape))
    {
      gameState = MENU;

      ResetGame();
    }
  }
  
  // Pre: Takes in game container to maniplate drawings
  // Post: None
  // Desc: Updateds all stuff for stats menu
  public void UpdateStats(GameContainer gc)
  {
    const int MAIN = 0;
    const int LEADERCHOOSE = 1;
    const int PERSONAL = 2;
    const int LEADER = 3;

    if (Input.IsKeyDown(ConsoleKey.Escape))
    {
      gameState = MENU;

      pointer = 0;

      chosenScreen = 0;
    }

    if (chosenScreen == 0)
    {
      pointerObject.SetPosition(30, 6 + (pointer * 10));

      if (Input.IsKeyDown(ConsoleKey.S) && pointer != 1)
      {
        pointer++;
      }
      else if (Input.IsKeyDown(ConsoleKey.W) && pointer != 0)
      {
        pointer--;
      }
      else if (Input.IsKeyDown(ConsoleKey.Enter))
      {
        if (pointer == 0)
        {
          chosenScreen = PERSONAL;
        }
        else
        {
          chosenScreen = LEADERCHOOSE;
        }

        pointer = 0;
      }
    }
    else if (chosenScreen == PERSONAL)
    {
      string[] userInfo = currentUser.GetStats().Split(',');

      usernameText.UpdateText("Username:" + userInfo[0]);
      maxGoldText.UpdateText("Most gold:" + userInfo[5]);
      maxLevelText.UpdateText("Highest level:" + userInfo[6]);
      lifetimeText.UpdateText("All-time gold:" + userInfo[3]);
      totalGamesText.UpdateText("Total games:" + userInfo[7]);
      totalKills.UpdateText("Total kills:" + userInfo[4]);
      averageGold.UpdateText("Average gold:" + currentUser.GetAverageGold() );

      if (Input.IsKeyDown(ConsoleKey.Escape))
      {
        chosenScreen = MAIN;
      }
    }
    else if (chosenScreen == LEADERCHOOSE)
    {
      pointerObject.SetPosition(30, 1 + (4 * pointer));

      if (Input.IsKeyDown(ConsoleKey.S) && pointer < 5)
      {
        pointer++;
      }
      else if (Input.IsKeyDown(ConsoleKey.W) && pointer > 0)
      {
        pointer--;
      }
      else if (Input.IsKeyDown(ConsoleKey.Enter))
      {
        currentSorting = pointer;
        BubbleSort();

        chosenScreen = LEADER;
      }
    }
    else
    {
      int displayAmount;

      if (users.Count <= 5)
      {
        displayAmount = users.Count;
      }
      else
      {
        displayAmount = 5;
      }

      for (int i = 0; i < displayAmount; i++)
      {
        leaderboardText[i * 2].UpdateText("Username: " + users[i].GetUsername());
        
        switch (currentSorting)
        {
          case MAXGOLD:
          leaderboardText[(i * 2) + 1].UpdateText("Max gold: " + users[i].GetMaxGold());
          break;

          case MAXLEVEL:
          leaderboardText[(i * 2) + 1].UpdateText("Max level: " + users[i].GetMaxLevel());
          break;

          case LIFETIMEGOLD:
          leaderboardText[(i * 2) + 1].UpdateText("Lifetime gold: " + users[i].GetTotalGold());
          break;

          case TOTALPLAYS:
          leaderboardText[(i * 2) + 1].UpdateText("Total games: " + users[i].GetTotalPlays());
          break;  

          case TOTALKILLS:
          leaderboardText[(i * 2) + 1].UpdateText("Total kills: " + users[i].GetTotalKills());
          break;

          case AVERAGEGOLD:
          leaderboardText[(i * 2) + 1].UpdateText("Average: " + users[i].GetAverageGold());
          break;
        }
        
      }
    }
  }

  // Pre: Takes in game container to maniplate drawings
  // Post: None
  // Desc: Updateds all stuff for the menu
  public void UpdateMenu(GameContainer gc)
  {
    pointerObject.SetPosition(30, 2 + (pointer * 5));

    if (Input.IsKeyDown(ConsoleKey.S) && pointer < 4)
    {
      pointer++;
    }
    else if (Input.IsKeyDown(ConsoleKey.W) && pointer > 0)
    {
      pointer--;
    }
    else if (Input.IsKeyDown(ConsoleKey.Enter))
    {
      if (pointer == 0)
      {
        gameState = GAMEPLAY;

        if (currentUser.GetLevel() == 1)
        {
          currentUser.SetGameAmount();

          SaveFile();
        }
        
        level = currentUser.GetLevel();
        levelText.UpdateText("Level:" + level);

        gold = currentUser.GetGold();
        goldText.UpdateText("Gold:" + gold);

        HP = currentUser.GetHP();
        homeHPBar.SetValue(HP);

        // Resets the new timer, adding the new and proper amount of time to for the user
        maxTime = (30000 + ((level - 1) * 3000));

        // Resets the time left timer
        timeLeft = (float)(maxTime);

        // Resets the max value of the bar and the actual value of the head start
        headStartBar.SetMax(maxTime);
        headStartBar.SetValue((int)timeLeft);
        
      }
      else if (pointer == 1)
      {
        gameState = INSTRUCTIONS;
      }
      else if (pointer == 2)
      {
        gameState = STATISTICS;

        pointer = 0;
      }
      else if (pointer == 3)
      {
        gameState = LOGIN;

        currentUser = null;

        pointer = 0;

        chosenScreen = 0;
      }
      else
      {
        gc.Stop();
      }
    }
  }

  // Pre: Takes in game container to maniplate drawings
  // Post: None
  // Desc: Updateds all stuff for logging in
  public void UpdateLogin(GameContainer gc)
  {
    const int MAIN = 0;
    const int CHOOSE = 1;
    const int CREATE = 2;

    if (chosenScreen == MAIN)
    {
      if (Input.IsKeyDown(ConsoleKey.S) && pointer == 0)
      {
        pointer = 1;
      }
      else if (Input.IsKeyDown(ConsoleKey.W) && pointer == 1)
      {
        pointer = 0;
      }
      else if (Input.IsKeyDown(ConsoleKey.Enter))
      {
        loginInfoText1.UpdateText("");

        if (pointer == 0)
        {
          chosenScreen = CHOOSE;
        }
        else
        {
          chosenScreen = CREATE;
        }
      }

      pointerObject.SetPosition(30, 6 + (pointer * 5));
    }
    else 
    {
      if (chosenScreen == CREATE)
      {
        loginInfoText.UpdateText("Press ENTER to finish making the new user. Pres ESC to go back");
      }
      else
      {
        loginInfoText.UpdateText("Press ENTER to find your user. Press ESC to go back");
      }
      
      if (Input.IsKeyDown(ConsoleKey.Backspace) && currentUsername.Length >= 1)
      {
        currentUsername = currentUsername.Substring(0, currentUsername.Length - 1);
      }
      else if (Input.IsKeyDown(ConsoleKey.Escape))
      {
        chosenScreen = MAIN;
        currentUsername = "";
      }
      else if (Input.IsKeyDown(ConsoleKey.Enter))
      {
        if (chosenScreen == CREATE)
        {
          if (FindUser(currentUsername) == null)
          {
            User newUser = new User(currentUsername, 20, 1, 0, 0, 0, 0, 0, 30);

            users.Add(newUser);

            currentUser = newUser;

            gameState = MENU;

            pointer = 0;

            SaveFile();

            currentUsername = "";

            chosenScreen = MAIN;
          }
          else
          {
            loginInfoText1.UpdateText("User alreadys exists");
          }
        }
        else
        {
          currentUser = FindUser(currentUsername);

          if (currentUser == null)
          {
            loginInfoText1.UpdateText("No user found, try again");
          }
          else
          {
            gameState = MENU;
            
            pointer = 0;

            currentUsername = "";

            chosenScreen = MAIN;
          }
        } 
      }
      else if (Input.IsKeyDown(ConsoleKey.A))
      {
        currentUsername += 'A';
      }
      else if (Input.IsKeyDown(ConsoleKey.B))
      {
        currentUsername += 'B';
      }
      else if (Input.IsKeyDown(ConsoleKey.C))
      {
        currentUsername += 'C';
      }
      else if (Input.IsKeyDown(ConsoleKey.D))
      {
        currentUsername += 'D';
      }
      else if (Input.IsKeyDown(ConsoleKey.E))
      {
        currentUsername += 'E';
      }
      else if (Input.IsKeyDown(ConsoleKey.F))
      {
        currentUsername += 'F';
      }
      else if (Input.IsKeyDown(ConsoleKey.G))
      {
        currentUsername += 'G';
      }
      else if (Input.IsKeyDown(ConsoleKey.H))
      {
        currentUsername += 'H';
      }
      else if (Input.IsKeyDown(ConsoleKey.I))
      {
        currentUsername += 'I';
      }
      else if (Input.IsKeyDown(ConsoleKey.J))
      {
        currentUsername += 'J';
      }
      else if (Input.IsKeyDown(ConsoleKey.K))
      {
        currentUsername += 'K';
      }
      else if (Input.IsKeyDown(ConsoleKey.L))
      {
        currentUsername += 'L';
      }
      else if (Input.IsKeyDown(ConsoleKey.M))
      {
        currentUsername += 'M';
      }
      else if (Input.IsKeyDown(ConsoleKey.N))
      {
        currentUsername += 'N';
      }
      else if (Input.IsKeyDown(ConsoleKey.O))
      {
        currentUsername += 'O';
      }
      else if (Input.IsKeyDown(ConsoleKey.P))
      {
        currentUsername += 'P';
      }
      else if (Input.IsKeyDown(ConsoleKey.Q))
      {
        currentUsername += 'Q';
      }
      else if (Input.IsKeyDown(ConsoleKey.R))
      {
        currentUsername += 'R';
      }
      else if (Input.IsKeyDown(ConsoleKey.S))
      {
        currentUsername += 'S';
      }
      else if (Input.IsKeyDown(ConsoleKey.T))
      {
        currentUsername += 'T';
      }
      else if (Input.IsKeyDown(ConsoleKey.U))
      {
        currentUsername += 'U';
      }
      else if (Input.IsKeyDown(ConsoleKey.V))
      {
        currentUsername += 'V';
      }
      else if (Input.IsKeyDown(ConsoleKey.W))
      {
        currentUsername += 'W';
      }
      else if (Input.IsKeyDown(ConsoleKey.X))
      {
        currentUsername += 'X';
      }
      else if (Input.IsKeyDown(ConsoleKey.Y))
      {
        currentUsername += 'Y';
      }
      else if (Input.IsKeyDown(ConsoleKey.Z))
      {
        currentUsername += 'Z';
      }

      currentUsernameText.UpdateText("Username:" + currentUsername);
    }

  }

  // Pre: Takes in game container to maniplate drawings
  // Post: None
  // Desc: Updateds all stuff for the end game
  public void UpdateEndgame(GameContainer gc)
  {
    // Checks if the player lost or not
    if (HP <= 0)
    {
      // Updates text to indicate if they lost or not
      endGameText.UpdateText("You've lost.... Press ENTER to continue");
    }
    else
    {
      // Updates text to indicate if they lost or not
      endGameText.UpdateText("You move onto the next level! Press ENTER to continue");
    }

    if (Input.IsKeyDown(ConsoleKey.Enter))
    {
      if (HP <= 0)
      {
        level = 1;
        gold = 20;

        HP = 30;

        ResetGame();

        gameState = MENU;

        currentUser.UpdateStatistics(level, gold, addsKilled + bossesKilled, HP);

        SaveFile();
      }
      else
      {
        totalGoldChange = 0;
        bossesKilled = 0;
        addsKilled = 0;
        towersPlaced = 0;

        gameState = GAMEPLAY;
      }

     
    }
  }

  // Pre: Takes in the game container to draw and the amount of time elapsed since last frame
  // Post: None
  // Desc: Does everything that must occur every frame of the game
  public void UpdateGame(float deltaTime, GameContainer gc)
  {
    // Creates 2 variables that calculate the cursor's current x,y coordinates in respect to the 2D array that is used to store tiles
    int yCursor = (cursor / tiles.GetLength(0));
    int xCursor = cursor - (tiles.GetLength(0) * yCursor);

    // Checks which key the user is pressing
    if (Input.IsKeyDown(ConsoleKey.DownArrow) && yCursor < 3)
    {
      // Increments cursor by correct amount that the player moved
      cursor += 10;

      // Switches the new tile so that it is selected
      tiles[xCursor, yCursor + 1].SelectTile(gc);

      // Switches previous tile so as to unselect it
      tiles[xCursor, yCursor].SelectTile(gc);
    }
    else if (Input.IsKeyDown(ConsoleKey.UpArrow) && yCursor > 0)
    {
      // Increments cursor by correct amount that the player moved
      cursor -= 10;

      // Switches the new tile so that it is selected
      tiles[xCursor, yCursor - 1].SelectTile(gc);

      // Switches previous tile so as to unselect it
      tiles[xCursor, yCursor].SelectTile(gc);
    }
    else if (Input.IsKeyDown(ConsoleKey.RightArrow) && xCursor < 9)
    {
      // Increments cursor by correct amount that the player moved
      cursor += 1;

      // Switches the new tile so that it is selected
      tiles[xCursor + 1, yCursor].SelectTile(gc);

      // Switches previous tile so as to unselect it
      tiles[xCursor, yCursor].SelectTile(gc);
    }
    else if (Input.IsKeyDown(ConsoleKey.LeftArrow) && xCursor > 0)
    {
      // Increments cursor by correct amount that the player moved
      cursor -= 1;

      // Switches the new tile so that it is selected
      tiles[xCursor - 1, yCursor].SelectTile(gc);

      // Switches previous tile so as to unselect it
      tiles[xCursor, yCursor].SelectTile(gc);
    }
    else if ((Input.IsKeyDown(ConsoleKey.D1) || Input.IsKeyDown(ConsoleKey.NumPad1)))
    {
      // Stores the current tile we are working on
      Tile curTile = tiles[xCursor, yCursor];

      // Creates a new game object of an archer tower at the correct position 
      GameObject ArcherTowerObject = new GameObject(gc, archerTowerImg, curTile.GetObject().GetPos().x + 1, curTile.GetObject().GetPos().y + 1, true);

      // Creates a new array of game objects to store the tiles of the range of the archer tower
      GameObject[] tileRange = new GameObject[ArcherTower.maxTiles];

      // Loops through the amount of tiles the archer tower has
      for (int i = 0; i < ArcherTower.maxTiles; i++)
      {
        // Checks if the tower range is out of bounds
        if (xCursor + i >= tiles.GetLength(0))
        {
          // Adds a null because it is out of bounds
          tileRange[i] = null;
        }
        else
        {
          // Adds a tile to the range of the tower
          tileRange[i] = tiles[xCursor + i, yCursor].GetObject();
        }
      }

      // Queues up a new archer tower
      queue.Enqueue( new ArcherTower(ArcherTowerObject, tileRange, arrowImg), tiles[xCursor,yCursor], Tower.ARCHER); 
    }
    else if ( (Input.IsKeyDown(ConsoleKey.D2) || Input.IsKeyDown(ConsoleKey.NumPad2)))
    {
      // Stores the current tile we are working on
      Tile curTile = tiles[xCursor, yCursor];

      // Creates a new game object of an archer tower at the correct position 
      GameObject BarrierObject = new GameObject(gc, barrierImg, curTile.GetObject().GetPos().x + 1, curTile.GetObject().GetPos().y + 1, true);

      queue.Enqueue(new Barrier(BarrierObject), tiles[xCursor, yCursor], Tower.BARRIER);
    }
    else if ((Input.IsKeyDown(ConsoleKey.D3) || Input.IsKeyDown(ConsoleKey.NumPad3)))
    {
      // Stores the current tile we are working on
      Tile curTile = tiles[xCursor, yCursor];

      // Creates a new game object of an archer tower at the correct position 
      GameObject TrapObject = new GameObject(gc, mudTrapImg, curTile.GetObject().GetPos().x + 1, curTile.GetObject().GetPos().y + 1, true);

      queue.Enqueue(new MudTrap(TrapObject), tiles[xCursor, yCursor], Tower.TRAP);
    }
    // SPACE FOR Cannon
    else if (Input.IsKeyDown(ConsoleKey.Q))
    {
      // Queues up an upgrade order
      queue.Enqueue(tiles[xCursor, yCursor].GetTower(), tiles[xCursor, yCursor], Tower.ARCHER + ActionQueue.TOWERNUMS);
      
    }
    else if (Input.IsKeyDown(ConsoleKey.W))
    {
      // Queues up an upgrade order
      queue.Enqueue(tiles[xCursor, yCursor].GetTower(), tiles[xCursor, yCursor], Tower.BARRIER + ActionQueue.TOWERNUMS);
    }
    else if (Input.IsKeyDown(ConsoleKey.E))
    {
      // Queues up an upgrade order
      queue.Enqueue(tiles[xCursor, yCursor].GetTower(), tiles[xCursor, yCursor], Tower.TRAP + ActionQueue.TOWERNUMS);
    }
    // space for cannon
    else if (Input.IsKeyDown(ConsoleKey.X) && tiles[xCursor, yCursor].TowerBuiltCheck())
    {
      // Creates variable to store the tower that is being deleted
      Tower deletedTower = tiles[xCursor, yCursor].GetTower();

      // Increases the amount of gold by refunding the tower
      gold += (int)(deletedTower.GetTotalCost() * REFUNDCOST);

      // Updates the gold amount
      goldText.UpdateText("Gold:" + gold);

      // Removes the tower from the list
      towerObjects.Remove(deletedTower);

      // Removes the tower from the tile
      tiles[xCursor, yCursor].RemoveTower();
    }
    else if (Input.IsKeyDown(ConsoleKey.Spacebar))
    {
      // Resets the time to be 0
      timeLeft = 0f;

      // Updates the timer bar
      headStartBar.SetValue((int)timeLeft);
    }
    else if (Input.IsKeyDown(ConsoleKey.Escape))
    {
      gameState = PAUSE;
    }

    // Makes a new variable to store the return value of the dequeue, the tower (if there is any)
    Tower[] towerDequeue = queue.Dequeue(deltaTime, gold);

    // Checks if there was a tower dequeued
    if (towerDequeue[0] != null)
    {
      // Subtracts the gold cost of that specific tower
      gold -= towerDequeue[0].GetCost( towerDequeue[0].CheckUpgraded() );

      // Updates statistic
      totalGoldChange -= towerDequeue[0].GetCost(towerDequeue[0].CheckUpgraded());

      towerDequeue[0].AddTotalCost(towerDequeue[0].GetCost( towerDequeue[0].CheckUpgraded() ));

      // Updates the gold text to feature the correct amount of gold
      goldText.UpdateText("Gold:" + gold);

      // Adds the newely dequeued tower
      towerObjects.Add(towerDequeue[0]);

      // Checks if the first tower was upgraded
      if (towerDequeue[0].CheckUpgraded())
      {
        // Removes the old tower as it shouldnt exist anymore
        towerObjects.Remove(towerDequeue[1]);
      }
      else
      {
        // Updates statisitic
        towersPlaced++;
      }
    } 

    // Correctly updates the active action text
    switch (queue.Peek())
    {
      case Tower.ARCHER:
      // Informs user of active action
      currentActiveText.UpdateText("-Archer Tower");
      break;

      case Tower.BARRIER:
      // Informs the user of active action
      currentActiveText.UpdateText("-Barrier");
      break;

      case Tower.TRAP:
      // Informs the user of active action
      currentActiveText.UpdateText("-Mud Trap");
      break;

      case Tower.INVALID:
      // Informs user of active action
      currentActiveText.UpdateText("-");
      break;
    }

    // Checks if there is still time for the player to be ready
    if (timeLeft > 0)
    {
      // Reduces the time
      timeLeft -= deltaTime;

      // Updates the timer bar
      headStartBar.SetValue((int)timeLeft);
    }
    else
    {
      // Checks if the stack is empty, if so fills it
      if (stack.GetCount() == 0 && spawnPhase == false)
      {
        // Set the spawn phase to true as it begins the attack
        spawnPhase = true;

        // Creates a random variable to roll numbers
        Random rng = new Random();

        // Loops through how many bosses should spawn
        for (int i = 0; i < Math.Min(level - 1, tiles.GetLength(1) - 1); i++)
        {
          // Pushes a new boss into stack
          stack.Push( new Boss(new GameObject(gc, bossImg, 0, 0, true)) );
        }

        // Adds the proper amount of enemies depending on the level
        for (int i = 0; i < (10 + ((level - 1) * 8)); i++)
        {
          if (rng.Next(0,101) <= (20 - Math.Min(5, (level - 1) * 0.5)))
          {
            stack.Push( new EnemyFM(new GameObject(gc, enemyFMImg, 0, 0, true)) );
          }
          else
          {
            // Adds the general enemy
            stack.Push( new EnemyGM(new GameObject(gc, enemyGMImg, 0, 0, true)) );
          }
        }

        // Reworks the adds left bar, to now properly account for the amount of adds left
        maxAdds = stack.GetCount();
        addsLeft = maxAdds;

        // Changes the values ofthe adds bar to properly account for amount of adds
        addsBar.SetMax(maxAdds);
        addsBar.SetValue(addsLeft);
      }

      // Calls upon the update game phase to handle updating the actual game phase
      UpdateGamePhase(gc, deltaTime);
    }

    // Calls the update enemies subprogram to handle updating
    UpdateEnemies(gc, deltaTime);

    // Loops through all bullets
    for (int i = 0; i < bullets.Count; i++)
    {
      // Updates their position by moving them
      bullets[i].Move(ArcherTower.bulletSpeed, 0);

      // Checks if the bullets are past a certain position
      if (bullets[i].GetPos().x >= 78)
      {
        // Removes them so they dont stay there againist the walling hogging RAM
        bullets.RemoveAt(i);
      }
    }

    // Loops through all towers
    for (int i = 0; i < towerObjects.Count; i++)
    {
      // Checks which tower it is currently
      switch (towerObjects[i].GetType())
      {
        case Tower.ARCHER:
        // Updates the firing timer of the archer tower
        ((ArcherTower)(towerObjects[i])).UpdateFireTimer(deltaTime);
        break;
      }
    }

  }

  // Pre: None
  // Post: None
  // Desc: Does all the work to update to the next level
  public void UpdateLevel()
  {
    // Sets the spawn phase to false as the attack finished fully
    spawnPhase = false;

    // Increments the level as the user passed a level
    level++;

    // Updates the text to reflect the new level
    levelText.UpdateText("Level:" + level);

    // Loops through all the rows of the tiles
    for (int i = 0; i < tiles.GetLength(0); i++)
    {
      // Loops through all the coloums of the tiles
      for (int b = 0; b < tiles.GetLength(1); b++)
      {
        // Removes the tower from the current tile
        tiles[i,b].RemoveTower();
      }
    }

    // Clears the bullets from screen
    bullets.Clear();

    // Creates constant to store the refund cost in the ending of a level
    const float LEVELREFUNDCOST = 0.75f;

    // Loops through all the towers
    for (int i = 0; i < towerObjects.Count; i++)
    {
      // Increases the amount of gold by refunding the tower
      gold += (int)(towerObjects[i].GetTotalCost() * LEVELREFUNDCOST);

      // Updates statistic
      totalGoldChange += (int)(towerObjects[i].GetTotalCost() * LEVELREFUNDCOST);
    }
    
    // Updates the gold text
    goldText.UpdateText("Gold:" + gold);

    // Clears all towers
    towerObjects.Clear();

    currentUser.UpdateStatistics(level, gold, addsKilled + bossesKilled, HP);

    SaveFile();

    // Sets the game state to end game
    gameState = ENDGAME;

    // Resets the new timer, adding the new and proper amount of time to for the user
    maxTime = (30000 + ((level - 1) * 3000));

    // Resets the time left timer
    timeLeft = (float)(maxTime);

    // Resets the max value of the bar and the actual value of the head start
    headStartBar.SetMax(maxTime);
    headStartBar.SetValue((int)timeLeft);
  }

  // Pre: Takes in a game container to draw and update the game, takes in a float of how much time passes since last call of this function
  // Post: None
  // Desc: Updates the actual game phase of the game, having waves spawn in
  public void UpdateGamePhase(GameContainer gc, float deltaTime)
  {
    // Defines a new random variable to be used for random numbers
    Random rng = new Random();

    if (stack.GetCount() > 0)
    {
      // Checks if the wave spawner has time to spawn another wave in
      if (waveSpawner <= 0)
      {
        // Resets the wave spawn timer
        waveSpawner = Math.Max(1000, (3000 - (level - 1) * 100));

        // Stores the newest enemy to be added
        Enemy newEnemy = stack.Pop();

        // Gives it a new randomized spawning location
        int newRow = rng.Next(0,4);

        // Loops while the new row chosen is the same as the previous row chosen
        while (newRow == prevRow)
        {
          // Rerolls the new row
          newRow = rng.Next(0,4);
        }

        // Redefines the prevRow as the newest row
        prevRow = newRow;
        
        // Creates constant to store where the enemy x position is located
        const int xStart = 76;

        if (newEnemy.GetBoss())
        {
          // Assigns the new enemy a GameObject so it can be drawn and manipulated
          newEnemy.GetObject().SetPosition(xStart, prevBossRow * Tile.tileWidth);

          // Checks if the boss spawning is reached the end of the rows
          if (prevBossRow == 3)
          {
            // Resets the row of the boss
            prevBossRow = 0;
          }
          else
          {
            // Increments the row of the boss
            prevBossRow++;
          }
        }
        else
        {
          // Assigns the new enemy a GameObject so it can be drawn and manipulated
          newEnemy.GetObject().SetPosition(xStart, newRow * Tile.tileWidth);
        }

        // Adds the new enemy into the main list of enemies
        enemies.Add(newEnemy);

        // Decreases the amount of adds left by 1
        addsLeft--;

        // Fixes the value of the adds bar to properly reflect amount of adds
        addsBar.SetValue(addsLeft);
      }
      else
      {
        // Brings down the timer by how much time has passed
        waveSpawner -= deltaTime;
      }
    }
    // Checks if the stack has finished spawning all the enemies
    else if (enemies.Count == 0)
    {
      // Calls upon the update level function
      UpdateLevel();

      ResetGame();

      
    }

  }

  // Pre: Takes in the game container to draw and update items, takes in a float of how much time passes since last calling this function
  // Post: None
  // Desc: Updates all collision detections and movements to do with the enemies.
  public void UpdateEnemies(GameContainer gc, float deltaTime)
  {
    // Loops through all enemies
    for (int i = 0; i < enemies.Count; i++)
    {
      // Checks if the enemy has reached the end
      if (enemies[i].GetObject().GetPos().x == 0)
      {
        if (enemies[i].GetBoss())
        {
          // Decreases HP of base
          HP -= Enemy.BOSSDAMAGE;
        }
        else
        {
          // Decrease HP of base
          HP -= Enemy.REGDAMAGE;
        }

        // Updates the HP bar
        homeHPBar.SetValue(HP);

        // Removes the enemy as it touched the base, therefore it died
        enemies.RemoveAt(i);

        // Checks if the home base died
        if (HP <= 0)
        {
          // Makes the game state to the end
          gameState = ENDGAME;

          // Returns out of the function as the base died
          return;
        }
      }
      else
      {
        // Creates a boolean to store whether or not a tower was collided with
        bool foundTowerCollision = false;

        // Loops through all towers
        for (int b = 0; b < towerObjects.Count; b++)
        {
          

          // Checks if the enemy is intersecting with a tower and a previous tower wasn't found
          if (!foundTowerCollision && Helper.FastIntersects(towerObjects[b].GetObject(), enemies[i].GetObject()) )
          {
            if (towerObjects[b].GetType() == Tower.TRAP && !enemies[i].GetSlowed() && !enemies[i].GetFlying())
            {
              // Slows down the enemy
              enemies[i].Slow(true);

              // Sets the new enemy speed
              enemies[i].SetSpeed(enemies[i].GetSpeed() * ((MudTrap)towerObjects[b]).GetSlowRate() );

              // Checks if all the uses on the mud trap has been used
              if (((MudTrap)(towerObjects[b])).Use()) 
              {
                // Removes the tower from the tile
                RemoveTile(towerObjects[b]);

                // Removes the tower 
                towerObjects.RemoveAt(b);

                // Breaks out of loop because the tower is gone
                break;
              }
            }
            
            if (towerObjects[b].GetType() != Tower.TRAP)
            {
              // Sets the boolean to true as it has not collided with a tower
              foundTowerCollision = true;

              // Checks if the enemy can attack
              if (enemies[i].CheckTime())
              {
                // Makes the tower take damage according to the enemy
                towerObjects[b].Damage(enemies[i].GetAP());

                // Resets the timer for the enemy, making it now wait all over again
                enemies[i].ResetTimer();

                // Checks if the tower is dead
                if (towerObjects[b].GetHP() <= 0)
                {
                  // Removes the tower from the tile
                  RemoveTile(towerObjects[b]);
                  // Removes the tower because it died
                  towerObjects.RemoveAt(b);
                  break;
                }
              }
            }
           
            // Since the enemy cant attack, updates it's timer so it gets closer to attacking
            enemies[i].UpdateTimer(deltaTime);
          }

          // Updates properly depending on the tower
          switch (towerObjects[b].GetType())
          {
            case Tower.ARCHER:
            // Assigns the current tower variable to the current archer tower
            ArcherTower currentTower = (ArcherTower)(towerObjects[b]);

            // Checks if there is an enemy within it's tile range and it can fire
            if (currentTower.CheckWithinTiles(enemies[i].GetObject()) && currentTower.CheckFire())
            {
              // Adds a bullet to the bullets list
              bullets.Add(currentTower.Shoot(gc));
            }

            break;
          }

        }

        // Checks if a collison with a tower is found
        if (!foundTowerCollision)
        {
          // Moves the enemy forward
          (enemies[i].GetObject()).Move(-enemies[i].GetSpeed(), 0);
        }

        // Checks enemy collision with any bullets
        for (int b = 0; b < bullets.Count; b++)
        {
          // Checks if there is a collision with the current bullet and current enemy
          if (Helper.FastIntersects(bullets[b], enemies[i].GetObject()))
          {
            // Reduces HP
            // TODO MAGIC NUM
            enemies[i].Damage(1);

            // Removes the bullet as it collided with the enemy
            bullets.RemoveAt(b);
            
            // Checks if the enemy is dead
            if (enemies[i].GetHP() <= 0)
            {
              // Adds the gold from the enemy to user
              gold += enemies[i].GetGold();

              // Updates statistic
              totalGoldChange += enemies[i].GetGold();

              // Updates the gold text
              goldText.UpdateText("Gold:" + gold);

              // Checks if the enemy was a boss or not
              if (enemies[i].GetBoss())
              {
                // Increments bosses killed
                bossesKilled++;
              }
              else
              {
                // Increments regular adds killed
                addsKilled++;
              }

              // Removes enemy as it died
              enemies.RemoveAt(i);

              // Breaks out as the bullet that hit the enemy has been found
              break;
            }

          }
        }
        
      }
    }
  }

  // Pre: None
  // Post: None
  // Desc: Resets the game
  public void ResetGame()
  {
    towerObjects.Clear();

    enemies.Clear();

    bullets.Clear();

    stack.Reset();

    queue.ResetQueues();

    spawnPhase = false;

    // Loops through all the rows of the tiles
    for (int i = 0; i < tiles.GetLength(0); i++)
    {
      // Loops through all the coloums of the tiles
      for (int b = 0; b < tiles.GetLength(1); b++)
      {
        // Removes the tower from the current tile
        tiles[i,b].RemoveTower();
      }
    }

  }

  // Pre: Takes in the tower to find
  // Post: None
  // Desc: Removes the tower from the tile
  public void RemoveTile(Tower towerToFind)
  {
    for (int i = 0; i < tiles.GetLength(0); i++)
    {
      for (int b = 0; b < tiles.GetLength(1); b++)
      {
        if (tiles[i,b].GetTower() == towerToFind)
        {
          tiles[i,b].RemoveTower();
          return;
        }
      }
    }
  }

  // Pre: Takes in a user name
  // Post: Returns the user object with that corresponding name
  // Desc:  Finds the user with the username
  public User FindUser(string username)
  {
    for (int i = 0; i < users.Count; i++)
    {
      if (users[i].GetUsername() == username)
      {
        return users[i];
      }
    }

    return null;
  }

  // Pre: None
  // Post: None
  // Desc: Reads the users from the file and adds them into the list
  public void ReadFile()
  {
    // Creates stream reader and opens the file
    StreamReader inFile = File.OpenText(fileName);

    // Creates an array to store the data of the line
    string[] data;

    // Loops while the file isnt done
    while (!inFile.EndOfStream)
    {
      data = inFile.ReadLine().Split(',');

      users.Add(new User(data[0],Convert.ToInt32(data[1]), Convert.ToInt32(data[2]), Convert.ToInt32(data[3]), Convert.ToInt32(data[4]), Convert.ToInt32(data[5]), Convert.ToInt32(data[6]), Convert.ToInt32(data[7]), Convert.ToInt32(data[8])));
    }

    inFile.Close();
  }

  // Pre: None
  // Post: None
  // Desc: Saves the users
  public void SaveFile()
  {
    StreamWriter outFile = File.CreateText(fileName);

    for (int i = 0; i < users.Count; i++)
    {
      outFile.WriteLine(users[i].GetStats());
    }

    outFile.Close();
  }

  // Pre: None
  // Post: None
  // Desc: Sorts the users by whatever sorting they want
  public void BubbleSort()
  {
    for (int _ = 0; _ < users.Count; _++)
    {
      for (int i = 0; i < (users.Count - 1); i++)
      {
        switch (currentSorting)
        {
          case MAXGOLD:
          if (users[i].GetMaxGold() < users[i + 1].GetMaxGold())
          {
            Swap(i, i + 1);
          }
          break;

          case MAXLEVEL:
          if (users[i].GetMaxLevel() < users[i + 1].GetMaxLevel())
          {
            Swap(i, i + 1);
          }
          break;

          case LIFETIMEGOLD:
          if (users[i].GetTotalGold() < users[i + 1].GetTotalGold())
          {
            Swap(i, i + 1);
          }
          break;

          case TOTALPLAYS:
          if (users[i].GetTotalPlays() < users[i + 1].GetTotalPlays())
          {
            Swap(i, i + 1);
          }
          break;

          case TOTALKILLS:
          if (users[i].GetTotalKills() < users[i + 1].GetTotalKills())
          {
            Swap(i, i + 1);
          }
          break;

          case AVERAGEGOLD:
          if (users[i].GetAverageGold() < users[i + 1].GetAverageGold())
          {
            Swap(i, i + 1);
          }
          break;
        }

      }
    }

  }

  // Pre: None
  // Post: None
  // Desc: Swaps two positions for the user list
  public void Swap(int index1, int index2)
  {
    User temp = users[index1];

    users[index1] = users[index2];
    users[index2] = temp;
  }

}