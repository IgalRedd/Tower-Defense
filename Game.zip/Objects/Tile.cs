//Author: Igal Brener
//FileName: Tile.cs
//Project Name: Final project
//Creation Date: 8 / 06 / 2021
//Modified Date: 16 / 06 / 2021
//Description: Creatse tiles

using System;

class Tile
{
  // Creates image variables to store the regular tile img and the selected tile img
  private Image tileImg;
  private Image selectedTileImg;

  // Stores the actual game object
  private GameObject tileObject;

  // Creates a boolean to store if the tile is selected or not, default is not selected
  private bool currentImgSelected = false;

  // Integer to store what type of tower is built on this tile
  private int typeOfTower;

  // Creates constants to store information about tiles
  public const int tileWidth = 5;
  public const int tileHeight = 7;
  public const int startingTileDistance = 5;

  // Creates variable to store the tower on the tile
  private Tower towerOnTile;

  // Pre: Takes in an image of the regular tile, takes in an image of the selected tile, takes in the game object of the actual tile
  // Post: None
  // Desc: Initiliazes the tile object
  public Tile(Image tileImg, Image selectedTileImg, GameObject tileObject)
  {
    // Loads the images and tile game object into this specific tile object
    this.tileImg = tileImg;
    this.selectedTileImg = selectedTileImg;
    this.tileObject = tileObject;

    // Sets it up as invalid from the first place because as of now there is no tower
    typeOfTower = Tower.INVALID;

    // Sets the tower to null as there isnt anything yet
    towerOnTile = null;
  }

  // Pre: None
  // Post: Returns the game object of the tile
  // Desc: Returns the game object of the tile to be used by other functions
  public GameObject GetObject()
  {
    // Returns the current tile game object
    return tileObject;
  }

  // Pre: Takes in a int that represents what type of tower is being built on the tile
  // Post: None
  // Desc: Stores the type of tower that is built on this tile
  public void AddTower(int typeOfTower, Tower newTower)
  {
    // Sets the tower type to the variable
    this.typeOfTower = typeOfTower;

    towerOnTile = newTower;
  }

  // Pre: None
  // Post: Returns the tower object that is on this tile
  // Desc: Gives the tower objec that is on this tile
  public Tower GetTower()
  {
    // Returns the tower object
    return towerOnTile;
  }

  //public Tower GetType

  // Pre: None
  // Post: None
  // Desc: Removes the tower info from this tile
  public void RemoveTower()
  {
    // Removes the type of tower
    typeOfTower = Tower.INVALID;

    // Removes the object
    towerOnTile = null;
  }

  // Pre: None
  // Post: Returns a boolean that indicates if there is a tower built or not
  // Desc: Checks if there is a tower built on the tile
  public bool TowerBuiltCheck()
  {
    // Checks if there is a valid tower in this tile
    if (typeOfTower == Tower.INVALID)
    {
      // Returns false as there is no tower
      return false;
    }

    // Returns true as there is a tower of some sort 
    return true;
  }

  // Pre: Takes in the game container to be able to create game objects
  // Post: None
  // Desc: Switches whether or not the tile is selected, both the boolean and the game object
  public void SelectTile(GameContainer gc)
  {
    // Checks if the tile is currently selected
    if (currentImgSelected == false)
    {
      // Switches the boolean to signify it's selected
      currentImgSelected = true;

      // Remakes the tile object so as to now use the image of the selected tile
      tileObject = new GameObject(gc, selectedTileImg, tileObject.GetPos().x, tileObject.GetPos().y, true);
    }
    else
    {
      // Switches the boolean to signify its unselected
      currentImgSelected = false;

      // Remakes the tile object so as to now use the image of the regular tile
      tileObject = new GameObject(gc, tileImg, tileObject.GetPos().x, tileObject.GetPos().y, true);
    }
  }
  
}