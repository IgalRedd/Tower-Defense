//Author: Igal Brener
//FileName: EnemyFM.cs
//Project Name: Final project
//Creation Date: 8 / 06 / 2021
//Modified Date: 16 / 06 / 2021
//Description: Creates flying enemy

using System;

class EnemyFM : Enemy
{
  // Creates constants for maximum amount and minimum of the cooldown to attack
  const int minCool = 300;
  const int maxCool = 500;

  // Creates constants to store the basic information about this type of Enemy
  const int HPStart = 4;
  const int APStart = 1;
  const float SpeedStart = 0.23f;
  const int gold = 2;

  // Pre: Takes in the game object of the enemy
  // Post: None
  // Desc: Creates the enemy
  public EnemyFM(GameObject enemyObject) : base(HPStart, APStart, minCool, maxCool, SpeedStart, gold, true, enemyObject, false)
  {
  }

}