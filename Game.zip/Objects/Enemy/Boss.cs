//Author: Igal Brener
//FileName: Boss.cs
//Project Name: Final project
//Creation Date: 8 / 06 / 2021
//Modified Date: 16 / 06 / 2021
//Description: Creates boss

using System;

class Boss : Enemy
{
  // Creates constants for maximum amount and minimum of the cooldown to attack
  const int minCool = 800;
  const int maxCool = 1200;

  // Creates constants to store the basic information about this type of Enemy
  const int HP = 50;
  const int AP = 4;
  const float speed = 0.06f;
  const int gold = 10;

  // Pre: Takes in the game object of the enemy
  // Post: None
  // Desc: Loads in boss
  public Boss(GameObject enemyObject) : base(HP, AP, minCool, maxCool, speed, gold, false, enemyObject, true)
  {
  }
}