//Author: Igal Brener
//FileName: EnemyGM.cs
//Project Name: Final project
//Creation Date: 8 / 06 / 2021
//Modified Date: 16 / 06 / 2021
//Description: Creates ground enemy

using System;

class EnemyGM : Enemy
{
  // Creates constants for maximum amount and minimum of the cooldown to attack
  const int minCool = 1000;
  const int maxCool = 1500;

  // Creates constants to store the basic information about this type of Enemy
  const int HPstart = 3;
  const int APStart = 2;
  const float SpeedStart = 0.08f;
  const int gold = 1;

  // Pre: Takes in the game object of the enmy
  // Post: None
  // Desc: Creates the enemy
  public EnemyGM(GameObject enemyObject) : base(HPstart, APStart, minCool, maxCool, SpeedStart, gold, false, enemyObject, false)
  {
  }

}