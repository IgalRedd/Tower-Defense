//Author: Igal Brener
//FileName: Enemy.cs
//Project Name: Final project
//Creation Date: 8 / 06 / 2021
//Modified Date: 16 / 06 / 2021
//Description: Creates enemy

using System;

class Enemy
{
  // Creates constants to store how much damage each enemy does to the base
  public const int REGDAMAGE = 1;
  public const int BOSSDAMAGE = 5;

  // Creates all the variables that are stored about the general enemy
  protected float HP;
  protected int AP;
  protected int cooldown;
  protected float speed;
  protected int goldDrop; 

  // Creates the timer of the enemy to see how long before next attack
  protected float timer = 0f;

  // Creates the game object of the enemy
  protected GameObject enemyObject;

  // Creates a boolean to store if the enemy has been slowed
  private bool slowed;

  // Creates a bool to check if this type of enemy is flying or not
  private bool flying;

  // Creates constant to store if the enemy is a boss or not
  private bool boss;

  // Pre: Takes in the HP of the enemy, the attack power, it's minimum cooldown before attack and maximum number, it's speed and how much gold it drops
  // Pre: None
  // Desc: creates enemy
  public Enemy(float HP, int AP, int minCool, int maxCool, float speed, int goldDrop, bool flying, GameObject enemyObject, bool boss)
  {
    // Sets all the basic variables to what was inputted
    this.HP = HP;
    this.AP = AP;
    this.speed = speed;
    this.goldDrop = goldDrop;
    this.enemyObject = enemyObject;

    // Creates local variable to be able to create random numbers
    Random rng = new Random();

    // Randomly picks the cooldown for enemy attacks between the minimum and maximum cooldown (inclusive)
    cooldown = rng.Next(minCool, maxCool + 1);

    // Sets it as false because for now it hasn't been slowed
    slowed = false;

    // Sets it to whether or not it is a boss
    this.boss = boss;

    // Sets whether or not the enemy is flying
    this.flying = flying;

  }

  // Pre: None
  // Post: Returns if it is a flyign enemy
  // Desc: Informs if the user if the enemy is flying
  public bool GetFlying()
  {
    return flying;
  }

  // Pre: None
  // Post: Returns a boolean if the enemy is a boss or not
  // Desc: Returns if it is a boss or not
  public bool GetBoss()
  {
    // Returns a boolean if the enemy is a boss or not
    return boss;
  }

  // Pre: None
  // Post: Returns the game object of the enemy
  // Desc: Gives the game object of the enemy
  public GameObject GetObject()
  {
    // Gives the game object of the enemy
    return enemyObject;
  }

  // Pre: None
  // Post: Returns a boolean if the enemy has been slowed or not
  // Desc: Tells if the enemy has been slowed
  public bool GetSlowed()
  {
    // Returns a boolean if the enemy has been slowed or not
    return slowed;
  }

  // Pre: None
  // Post: None
  // Desc: Makes the enemy slow
  public void Slow(bool newSlow)
  {
    // Makes the enemy slow
    slowed = newSlow;
  }

  // Pre: None
  // Post: Returns the float speed of the enemy
  // Desc: Gives the speed of the enemy
  public float GetSpeed()
  {
    // Gives the speed of the enemy
    return speed;
  }

  // Pre: Takes in a float value of the new speed
  // Post: None
  // Desc: Sets the new speed
  public void SetSpeed(float newSpeed)
  {
    // Sets the new speed
    speed = newSpeed;
  }

  // Pre: None
  // Post: Returns the current HP of the enemy
  // Desc: Returns the current HP of the enemy
  public float GetHP()
  {
    // Returns the current HP of the enemy
    return HP;
  }

  // Pre: None
  // Post: Returns the attack power of the enemy
  // Desc: Returns the attack power of the enemy
  public int GetAP()
  {
    // Returns the attack power of the enemy
    return AP;
  }

  // Pre: None
  // Post: Returns the amount of gold dropped by the enemy
  // Desc: Returns the amount of gold dropped by the enemy
  public int GetGold()
  {
    // Returns the amount of gold dropped by the enemy
    return goldDrop;
  }
  
  // Pre: Takes in a float of how much time passed since last calling of this function
  // Post: None
  // Desc: Takes in a float of how much time passed since last calling of this function
  public void UpdateTimer(float deltaTime)
  {
    // Updates the timer
    timer += deltaTime;
  }

  // Pre: None
  // Post: None
  // Desc: Resets the timer of the enemy attack
  public void ResetTimer()
  {
    // Resets the timer of the enemy attack
    timer = 0f;
  }

  // Pre: None
  // Post: Returns a boolean if enough time passed for the enemy to attack
  // Desc: Checks if the enemy can attack, given enough time passed
  public bool CheckTime()
  {
    // Checks if the enemy can attack, given enough time passed
    return timer >= cooldown;
  }

  // Pre: Takes in the amount of damage taken
  // Post: None
  // Desc: Damages the enemy
  public void Damage(float damageTaken)
  {
    // Damages the enemy
    HP -= damageTaken;
  }
}