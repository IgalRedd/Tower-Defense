//Author: Igal Brener
//FileName: ActionQueue.cs
//Project Name: Final project
//Creation Date: 8 / 06 / 2021
//Modified Date: 16 / 06 / 2021
//Description: creates the queue

using System;

// Imports library to be used for making lists
using System.Collections.Generic;

class ActionQueue
{
  // Stores integers for the main queue of which objects to update
  private List<int> queue = new List<int>();

  // Stores queues for each the tower objects
  private List<Tower> towerQueue = new List<Tower>();

  // Stores the list of the tiles they are working on
  private List<Tile> tiles = new List<Tile>();

  // Creates a constant to store how many tower possabilities there are
  public const int TOWERNUMS = 4;

  // Pre: None
  // Post: None
  // Desc: Resets all the queues
  public void ResetQueues()
  {
    queue.Clear();

    tiles.Clear();

    towerQueue.Clear();
  }

  // Pre: None
  // Post: Returns an integer of which tower is being worked on, regardless if its upgrade or building
  // Desc: Returns the tower being built / upgraded currently
  public int Peek()
  {
    // Checks if the queue is empty
    if (queue.Count == 0)
    {
      // Returns invalid num as there no towers
      return Tower.INVALID;
    } 
    
    // Checks if the queue is above 4, this means that an upgrade is happening 
    if (queue[0] > TOWERNUMS)
    {
      // Returns the queue - the limit on the upgrade, every number past 4 is an upgrade corresponding to it's own tower
      return queue[0] - TOWERNUMS;
    }

    // Return the tower being built
    return queue[0];
  }

  // Pre: Takes in a float of how much time passes since last update and the amount of gold the player has
  // Post: Returns the tower that is being dequeued
  // Desc: Updates the first item of the queue to the correct size and checks if it has finishes building, if so removes it from the queue
  public Tower[] Dequeue(float deltaTime, int gold)
  {
    // Creates a local constant to indicate an invalid tower
    const Tower INVALID = null;

    // Creates constants to deal with upgrades
    const int ARCHERUPG = Tower.ARCHER + TOWERNUMS;
    const int CANNONUPG = Tower.CANNON + TOWERNUMS;
    const int TRAPUPG = Tower.TRAP + TOWERNUMS;
    const int BARRIERUPG = Tower.BARRIER + TOWERNUMS;

    // Constant to store the amount of arguements you are returning 
    //const int returnArgCount = 2;

    // Creates an array to store what we are returning
    Tower[] returnArg = {null, null};

    // Checks if there is anything in the queue
    if (queue.Count > 0)
    {
      // Checks if there is already possibily a tower on the tile or the player doesnt have enough gold
      if (queue[0] <= TOWERNUMS)
      {
        if (tiles[0].TowerBuiltCheck() || !(towerQueue[0]).CheckCost(false, gold))
        {
          // Removes the item from all queues as it is invalid and the action cannot be completed
          tiles.RemoveAt(0);
          towerQueue.RemoveAt(0);
          queue.RemoveAt(0);

          // Returns invalid as no tower was dequeued
          return returnArg;
        }
      }
      else
      {
        // Checks if there is a tower there and the user has enough gold to upgrade
        if (!tiles[0].TowerBuiltCheck() || !towerQueue[0].CheckCost(true, gold) || towerQueue[0].CheckUpgraded())
        {
          // Removes the item from all queues as it is invalid and the action cannot be completed
          tiles.RemoveAt(0);
          towerQueue.RemoveAt(0);
          queue.RemoveAt(0);

          // Returns invalid as no tower was dequeued
          return returnArg;
        }
        else if (tiles[0].GetTower().GetType() != queue[0] - TOWERNUMS)
        {
          // Removes the item from all queues as it is invalid and the action cannot be completed
          tiles.RemoveAt(0);
          towerQueue.RemoveAt(0);
          queue.RemoveAt(0);

          // Returns invalid as no tower was dequeued
          return returnArg;
        }
      }

      // Updates the correct specific queue
      switch (queue[0])
      {
        case Tower.ARCHER:
        // Checks if the tower is done upgrading
        if ( !((ArcherTower)(towerQueue[0])).CheckTime(false) )
        {
          // Updates the tower's time as it still needs ot be built
          ((ArcherTower)(towerQueue[0])).UpdateTime(deltaTime, false);

          // Returns invalid as the tower isnt ready yet
          return returnArg;
        }
      
        // Denotes on the tile that a tower is built there now
        tiles[0].AddTower(Tower.ARCHER, towerQueue[0]);

        break;

        case Tower.BARRIER:
        // Checks if enough time has passed to build
        if ( !((Barrier)(towerQueue[0])).CheckTime(false) )
        {
          // Updates the time as not enough time has passed
          ((Barrier)(towerQueue[0])).UpdateTime(deltaTime, false);

          // Returns invalid because no tower is done
          return returnArg;
        }

        // Denotes on the tile that a tower is built there now
        tiles[0].AddTower(Tower.BARRIER, towerQueue[0]);
        break;

        case Tower.TRAP:
        // Checks if enough time has passed to build
        if ( !((MudTrap)(towerQueue[0])).CheckTime(false) )
        {
          // Updates the time as not enough time has passed
          ((MudTrap)(towerQueue[0])).UpdateTime(deltaTime, false);

          // Returns invalid because no tower is done
          return returnArg;
        }

        // Denotes on the tile that a tower is built there now
        tiles[0].AddTower(Tower.TRAP, towerQueue[0]);
        break;

        // CASE CANNON

        case ARCHERUPG:
        // Checks if there is enough time passed for the upgrade
        if ( !((ArcherTower)(towerQueue[0])).CheckTime(true))
        {
          // Updates the time as not enough time has passed
          ((ArcherTower)(towerQueue[0])).UpdateTime(deltaTime, true);

          // Returns invalid because no tower is done
          return returnArg;
        }

        // Calls upon the upgrade function for the tower
        ((ArcherTower)towerQueue[0]).Upgrade();

        // Saves the old tower as it is important we can later delete this tower
        returnArg[1] = towerQueue[0];
        break;

        case BARRIERUPG:
        // Checks if there is enough time passed for the upgrade
        if ( !((Barrier)(towerQueue[0])).CheckTime(true))
        {
          // Updates the time as not enough time has passed
          ((Barrier)(towerQueue[0])).UpdateTime(deltaTime, true);

          // Returns invalid because no tower is done
          return returnArg;
        }

        // Calls upon the upgrade function for the tower
        ((Barrier)towerQueue[0]).Upgrade();

        // Saves the old tower as it is important we can later delete this tower
        returnArg[1] = towerQueue[0];
        break;

        case TRAPUPG:
        // Checks if there is enough time passed for the upgrade
        if ( !((MudTrap)(towerQueue[0])).CheckTime(true))
        {
          // Updates the time as not enough time has passed
          ((MudTrap)(towerQueue[0])).UpdateTime(deltaTime, true);

          // Returns invalid because no tower is done
          return returnArg;
        }

        // Calls upon the upgrade function for the tower
        ((MudTrap)towerQueue[0]).Upgrade();

        // Saves the old tower as it is important we can later delete this tower
        returnArg[1] = towerQueue[0];
        break;

      }

      // Gets the tower to store it
      Tower towerBuilt = towerQueue[0];

      // Removes the item from all queues as it is complete and ready
      tiles.RemoveAt(0);
      towerQueue.RemoveAt(0);
      queue.RemoveAt(0);

      // Sets the first return arguement as the tower being built
      returnArg[0] = towerBuilt;

      // Returns the return arguements
      return returnArg;
    }
    
    // Returns invalid as there is nothing in the queue
    return returnArg; 
  }

  // Pre: Takes in a general tower object, the tile at which the tower is added and the type of action that is being added (whether it be upgrading or building)
  // Post: None
  // Desc: Enqueues a new archer tower into the main queue and specific archer queue
  public void Enqueue(Tower newTower, Tile tileAdded, int typeOfAction)
  {
    // Adds the integer of which action is added
    queue.Add(typeOfAction);

    // Adds the tile that is being worked on
    tiles.Add(tileAdded);

    // Adds the new tower into the queue
    towerQueue.Add(newTower);
  }

}