//Author: Igal Brener
//FileName: EnemyStack.cs
//Project Name: Final project
//Creation Date: 8 / 06 / 2021
//Modified Date: 16 / 06 / 2021
//Description: Creates enemy stack

using System;

// Imports the library for lists
using System.Collections.Generic;

class EnemyStack
{
  // Creates a list to store all the enemies of the stack
  private List<Enemy> enemies = new List<Enemy>();

  // Pre: Takes in an enemy object that is the new enemy being added
  // Post: None
  // Desc: Adds the enemy to the stack
  public void Push(Enemy newEnemy)
  {
    // Adds the new enemy into the stack
    enemies.Add(newEnemy);
  }

  // Pre: None
  // Post: None
  // Desc: Resets the stack
  public void Reset()
  {
    enemies.Clear();
  }

  // Pre: None
  // Post: Returns the enemy object
  public Enemy Pop()
  {
    // Checks if there are any enemies to give
    if (enemies.Count > 0)
    {
      // Stores the enemy so as to be used later
      Enemy enemyToPop = enemies[enemies.Count - 1];

      // Removes the last enemy as it is no longer in the list
      enemies.RemoveAt(enemies.Count - 1);

      // Returns the stored enemy so it can be used
      return enemyToPop;
    }

    // Returns null because there is no enemy to give
    return null;
  }

  // Pre: None
  // Post: Returns an integer of how much is in the stack
  // Desc: Tells the user how many items are in the stack
  public int GetCount()
  {
    // Returns the count of the enemies list
    return enemies.Count;
  }
}