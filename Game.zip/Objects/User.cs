//Author: Igal Brener
//FileName: User.cs
//Project Name: Final project
//Creation Date: 8 / 06 / 2021
//Modified Date: 16 / 06 / 2021
//Description: Creates user

using System;

class User
{
  // Stores information about specific user
  private int gold;
  private int level;
  private int HP;

  // Stores stats about user
  private int lifetimeGold;
  private int totalKills;
  private int maxGold;
  private int maxLevel;
  private int totalGames;
  private int averageGold;

  // Stores username
  private string username;

  // Pre: Takes in the user name and all the stats
  // Post: None
  // Desc: Creates user
  public User(string username, int gold, int level, int lifetimeGold, int totalKills, int maxGold, int maxLevel, int totalGames, int HP)
  {
    this.username = username;
    this.gold = gold;
    this.level = level;
    this.HP = HP;

    this.lifetimeGold = lifetimeGold;
    this.totalKills = totalKills;
    this.maxGold = maxGold;
    this.maxLevel = maxLevel;
    this.totalGames = totalGames;
    
    if (totalGames == 0)
    {
      averageGold = 0;
    }
    else
    {
      averageGold = (int)(lifetimeGold / totalGames);
    }
  }

  // Pre: None
  // Post: Returns an integer of the level
  // Desc: Gets the level of the user
  public int GetLevel()
  { 
    return level;
  }

  // Pre: None
  // Post: Returns the gold amount of the user
  // Desc: Gets the gold of the user
  public int GetGold()
  {
    // Returns the gold
    return gold;
  }

  // Pre: None
  // Post: Returns the username of the user
  // Desc: Gives the username of the user
  public string GetUsername()
  {
    // Returns the username of the user
    return username;
  }

  public void SetGameAmount()
  {
    totalGames++;
  }

  public int GetHP()
  {
    return HP;
  }


  public int GetMaxGold()
  {
    return maxGold;
  }

  public int GetMaxLevel()
  {
    return maxLevel;
  }

  public int GetTotalGold()
  {
    return lifetimeGold;
  }

  public int GetTotalPlays()
  {
    return totalGames;
  }

  public int GetTotalKills()
  {
    return totalKills;
  }

  public int GetAverageGold()
  {
    return averageGold;
  }



  public string GetStats()
  {
    string line = "";

    line += username + "," + gold + "," + level + ",";
    line += lifetimeGold + "," + totalKills + "," + maxGold + "," + maxLevel + "," + totalGames + "," + HP;

    return line;
  
  }

  public void UpdateStatistics(int newLevel, int newGold, int kills, int HP)
  {
    this.HP = HP;

    lifetimeGold += newGold;

    if (newGold > maxGold)
    {
      maxGold = newGold;
    }

    if (newLevel > maxLevel)
    {
      maxLevel = newLevel;
    }

    averageGold = (int)(lifetimeGold / totalGames);

    totalKills += kills;

    level = newLevel;

    gold = newGold;
  }
}