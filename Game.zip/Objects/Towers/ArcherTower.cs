//Author: Igal Brener
//FileName: ArcherTower.cs
//Project Name: Final project
//Creation Date: 8 / 06 / 2021
//Modified Date: 16 / 06 / 2021
//Description: Creates archer towers

using System;

class ArcherTower : Tower
{
  // Creates constant to store the amount of time it takes to build the tower
  const int BUILDTIME = 3000;

  // Stores a public constant to store the amount of gold needed to build this tower
  public const int GOLDNEEDED = 10;

  // Creates a constant to store the amount of HP the tower starts with
  const int HPstart = 10;

  // Creates a public constant to store the max amount of tiles the tower can see
  public const int maxTiles = 8;

  // Creates a variable to store all the tile the tower can see
  GameObject[] tileRange;

  // Variable to store how many tiles the archer tower can currently see
  int currentTileRange;

  float AP = 1;

  // Stores the image of the arrow the tower shoot
  Image arrowImg;

  // Creates a public constant to be used to know the bullet speed
  public const float bulletSpeed = 0.25f;

  // Creates a variable to store how long it takes to fire and the current timer on how long before the next shot is fired off
  float curFireTimer = 500f;
  // TODO MAKE THIS NOT MAGIC
  int fireTimer = 500;

  // Pre: Takes in a valid GameObject of te tower, the range of the archer tower and the arrow image that it shoots
  // Post: None
  // Desc: Initializes the archer tower
  public ArcherTower(GameObject towerObject, GameObject[] tileRange, Image arrowImg) : base(towerObject, Tower.ARCHER, GOLDNEEDED, HPstart)
  {
    // TODO MAGIC NUM
    currentTileRange = 6;

    // Sets the tile range of the archer tower to the input
    this.tileRange = tileRange;

    // Stores the image of the arrow
    this.arrowImg = arrowImg;
  }

  // Pre: Takes in a boolean to indiciate if this timer is checking for an upgrade or a new building
  // Post: Returns a boolean to see if it's corresponding time has passes, eg: if it finished building / upgrading
  // Desc: Checks 
  public bool CheckTime(bool upgrading)
  {
    // Checks if the user is upgrading or building
    if (upgrading == false)
    {
      // Returns check if the timer passed for regular build time
      return buildTime >= BUILDTIME;
    }
    
    // Returns check if the timer is passed for upgrade time
    return upgradeTime >= (BUILDTIME / 2);
  }

  // Pre: Takes in an object to check if this is within the range of the tower
  // Post: Returns a boolean if its within range
  // Desc: Checks if the game object is within the tile range of the tower
  public bool CheckWithinTiles(GameObject objectToCheck)
  {
    // Loops through all the current tiles
    for (int i = 0; i < currentTileRange; i++)
    {
      if (tileRange[i] == null)
      {
        return false;
      }
      // Checks if there is an intersection with the current tile
      else if (Helper.FastIntersects(objectToCheck, tileRange[i]))
      {
        // Returns true as there is collision
        return true;
      }
    }

    // Returns false as it went through all the tiles and found none
    return false;
  }

  // Pre: Takes in a game container object to be able to create game objects
  // Post: Returns a game object of the arrow being shot
  // Desc: Creates and returns an arrow that is shot out of the tower
  public GameObject Shoot(GameContainer gc)
  {
    // Returns the arrow that is shot
    GameObject bulletObj = new GameObject(gc, arrowImg, towerObject.GetPos().x + 4, towerObject.GetPos().y + 1, true);

    return bulletObj;
  }

  // Pre: Takes in a float of the time passed since last update
  // Post: None
  // Desc: Updates the firing timer to reflect how much time actually passed
  public void UpdateFireTimer(float deltaTime)
  {
    // Increments the firing timer
    curFireTimer += deltaTime;
  }

  // Pre: None
  // Post: Returns a boolean if the tower can shoot or not
  // Desc: Checks if the tower can shoot, if the timer has passed that it is allowed to fire
  public bool CheckFire()
  {
    // Checks if the timer can shoot
    if (curFireTimer >= fireTimer)
    {
      // Resets the firing timer
      curFireTimer = 0f;

      // Returns true as the tower can shoot
      return true;
    }

    // Returns false as the tower cannot shoot yet
    return false;
  }

  // Pre: None
  // Post: None
  // Desc: Updates the tower so all of it's stats can be upgraded
  public void Upgrade()
  {
    // Creates constants to store all the new stats that come with the upgrades
    const int upgradedCooldown = 300;
    const int upgradedRange = 8;
    const float upgradedAP = 2.8f;

    // Sets the new attributes of the tower
    currentTileRange = upgradedRange;
    fireTimer = upgradedCooldown;
    AP = upgradedAP;

    // Sets the upgraded boolean to true
    upgraded = true;
  }

  
}