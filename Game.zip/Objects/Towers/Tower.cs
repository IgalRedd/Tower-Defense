//Author: Igal Brener
//FileName: Tower.cs
//Project Name: Final project
//Creation Date: 8 / 06 / 2021
//Modified Date: 16 / 06 / 2021
//Description: creates towers

using System;

class Tower
{
  // Creates a protected variable to store the amount of time for building and upgrading
  protected float buildTime = 0f;
  protected float upgradeTime = 0f;

  // Creates a boolean to see if a tower has been upgraded
  protected bool upgraded = false;

  // Integer to store the types of tower it might be
  protected int typeOfTower;

  // Stores the variable of the cost of the tower
  private int goldCost;

  // Creates a variable to store the HP of the tower
  protected int HP;

  // Creates variable to store the total amount of gold spent on this tower
  private int totalGoldCost;

  // Creates constants to store the different types of towers
  public const int ARCHER = 1;
  public const int CANNON = 2;
  public const int BARRIER = 3;
  public const int TRAP = 4;
  public const int INVALID = -1;

  // Creates a variable to store the game GameObject
  protected GameObject towerObject;

  // Pre: Takes in a game object of the tower, an integer of which type of tower it is, the amount of gold it costs to build this tower and the HP of the tower
  // Post: None
  // Desc: Creates the tower
  public Tower(GameObject towerObject, int typeOfTower, int goldCost, int HP)
  {
    // Sets all the class variables to the input
    this.towerObject = towerObject;
    this.typeOfTower = typeOfTower;
    this.goldCost = goldCost;
    this.HP = HP;

    totalGoldCost = 0;
  }

  // Pre: None
  // Post: Returns a boolean on if the tower is upgraded or not
  // Desc: Checks if the tower is upgraded
  public bool CheckUpgraded()
  {
    // Returns a boolean on if the tower is upgraded or not
    return upgraded;
  }

  // Pre: Takes in a float of the amount of time passes since last calling this, as well as boolean if the tower is being upgraded or built
  // Post: None
  // Desc: Updates the timer of the tower
  public void UpdateTime(float timePassed, bool upgrading)
  {
    // Checks if it is upgrading
    if (upgrading)
    {
      // Updates the timer 
      upgradeTime += timePassed;
    }
    else
    {
      // Updates the timer 
      buildTime += timePassed;
    }
  }

  // Pre: None
  // Post: Returns an integer of the HP
  // Desc: Gives the current HP of the tower
  public int GetHP()
  {
    // Returns the current HP
    return HP;
  }

  // Pre: None
  // Post: Returns an integer of the type of tower
  // Desc: Returns the type of tower this is
  public int GetType()
  {
    // Gives the type of tower
    return typeOfTower;
  }

  // Pre: None
  // Post: Returns the game object of the tower
  // Desc: Returns the game object of the tower to be used
  public GameObject GetObject()
  {
    // Returns the game object of the tower
    return towerObject;
  }

  public int GetCost(bool upgrading)
  {
    if (upgrading)
    {
      return goldCost / 2;
    }

    return goldCost;
  }

  // Pre: None
  // Post: Returns an integer of the gold cost
  // Desc: Gives the cost of the tower in gold
  public bool CheckCost(bool upgrading, int gold)
  {
    // Checks if the tower is upgrading
    if (upgrading)
    {
      // If upgrading then returns the cost divided by half
      return gold >= (goldCost / 2);
    }

    // Returns the gold cost
    return gold >= goldCost;
  }

  // Pre: Takes in an integer of how much damage 
  // Post: None
  // Desc: Updates the HP to make it take the correct amount of damage
  public void Damage(int damageTaken)
  {
    // Reduces HP by damage taken
    HP -= damageTaken;
  }

  // Pre: Takes in an integer of how much more was spent on this tower
  // Post: None
  // Desc: Updates the total amount of gold spent on this tower
  public void AddTotalCost(int addingCost)
  {
    // Increments the total gold cost
    totalGoldCost += addingCost;
  }

  // Pre: None
  // Post: Returns an integer of the total cost
  // Desc: Gives the total cost of the tower, the total amount spent on it
  public int GetTotalCost()
  {
    // Returns the total cost
    return totalGoldCost;
  }

}