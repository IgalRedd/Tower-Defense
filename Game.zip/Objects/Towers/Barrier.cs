//Author: Igal Brener
//FileName: Barrier.cs
//Project Name: Final project
//Creation Date: 8 / 06 / 2021
//Modified Date: 16 / 06 / 2021
//Description: Creates barrier tower

using System;

class Barrier : Tower
{
  const int HPstart = 20;

  const int GOLDNEEDED = 20;

  const int BUILDTIME = 600;

  public Barrier(GameObject towerObject) : base(towerObject, Tower.BARRIER, GOLDNEEDED, HPstart)
  {

  }

  // Pre: Takes in a bool if the tower is being upgraded or built
  // Post: Returns a bool if the time enough has passed to build / upgrade
  // Desc: Checks if enough time passed for the upgrade / build
  public bool CheckTime(bool upgrading)
  {
    // Checks if the user is upgrading or building
    if (upgrading == false)
    {
      // Returns check if the timer passed for regular build time
      return buildTime >= BUILDTIME;
    }
    
    // Returns check if the timer is passed for upgrade time
    return upgradeTime >= (BUILDTIME / 2);
  }

  // Pre: None
  // Post: None
  // Desc: Upgrades the tower
  public void Upgrade()
  {
    // Creates contant to store the new upgraded HP
    const int upgradeHP = 30;

    // Sets the HP to the constant
    HP = upgradeHP;

    // Sets the upgraded bool to true
    upgraded = true;
  }
}