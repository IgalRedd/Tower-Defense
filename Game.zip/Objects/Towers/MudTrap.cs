//Author: Igal Brener
//FileName: MudTrap.cs
//Project Name: Final project
//Creation Date: 8 / 06 / 2021
//Modified Date: 16 / 06 / 2021
//Description: Creates mud trap

using System;

class MudTrap : Tower
{
  // Creates constants to store important information about the mud trap
  const int HP = 0;
  const int GOLDNEEDED = 30;
  const int BUILDTIME = 5000;

  // Storews how many uses it has
  private int uses;

  // The slow rate it has
  private float slowRate;

  // Pre: Takes in the game object of the tower
  // Post: None
  // Desc: Creates the trap
  public MudTrap(GameObject towerObject) : base(towerObject, Tower.TRAP, GOLDNEEDED, HP)
  {
    slowRate = 0.5f;
    uses = 5;
  }

  // Pre: None
  // Post: Returns the float of the slow rate
  // Desc: Gives the slow rate of the trap
  public float GetSlowRate()
  {
    // Returns the slow rate
    return slowRate;
  }

  // Pre: Takes in a bool if the tower is being upgraded or built
  // Post: Returns a bool if the time enough has passed to build / upgrade
  // Desc: Checks if enough time passed for the upgrade / build
  public bool CheckTime(bool upgrading)
  {
    // Checks if the user is upgrading or building
    if (upgrading == false)
    {
      // Returns check if the timer passed for regular build time
      return buildTime >= BUILDTIME;
    }
    
    // Returns check if the timer is passed for upgrade time
    return upgradeTime >= (BUILDTIME / 2);
  }

  // Pre: None
  // Post: Returns a bool if all the uses are gone
  // Desc: Uses one of the mud trap and checks if all the uses are gone
  public bool Use()
  {
    // Decreases the use
    uses--;

    // Checks if all the uses are gone
    if (uses == 0)
    {
      // Returns true because the uses are all gone
      return true;
    }

    // Returns false because not all uses are gone
    return false;
  }

  // Pre: None
  // Post: None
  // Desc: Upgrades all the values for the trap
  public void Upgrade()
  {
    // Creates the constants to store the upgraded values
    const float upgradedSlowRate = 0.3f;
    const int upgradedUses = 8;

    // Sets the new values for the trap
    uses = upgradedUses;
    slowRate = upgradedSlowRate;

    // Sets the upgraded boolean to true
    upgraded = true;
  }

}